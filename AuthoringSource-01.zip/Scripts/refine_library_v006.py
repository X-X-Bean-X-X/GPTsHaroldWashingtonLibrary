"""Versioned roof/ornament rebuild. Original source and imported V3 remain intact."""
import bpy,bmesh,math,json,shutil
import numpy as np
from pathlib import Path
from mathutils import Vector
from io_scene_fbx import parse_fbx
R=Path(__file__).resolve().parents[1]
W=63.42554414;D=109.24487609;H=39.624
bpy.ops.wm.open_mainfile(filepath=str(R/'Source/X_Bean_X_HaroldWashingtonLibrary_v003.blend'))
scene=bpy.context.scene
mat=bpy.data.materials.get('X_Bean_X_HWL_Atlas')
code=(R/'Scripts/build_library.py').read_text()
exec(code[code.index('class Builder:'):code.index("body=Builder(")])
stage=R/'ImportV006/HaroldWashingtonLibraryV6';stage.mkdir(parents=True,exist_ok=True)
tex=R/'Textures/V006';tex.mkdir(exist_ok=True)
# Modify original atlas in Blender; all four original maps remain untouched.
for suffix in ['BaseColor','MaskMap','Normal','ControlMask']:
    img=bpy.data.images.load(str(R/'Textures'/('HWL_'+suffix+'.png')),check_existing=False)
    a=np.array(img.pixels[:],dtype=np.float32).reshape(2048,2048,4)
    for tile in [2,7]:
        row=tile//4;col=tile%4;v=a[(3-row)*512:(4-row)*512,col*512:(col+1)*512]
        if suffix=='BaseColor':
            # Image pixels are linear. Maintain original patina variation.
            lum=np.maximum(v[:,:,:3].mean(axis=2),.005)
            variation=np.clip(lum/max(float(lum.mean()),.005),.72,1.22)
            v[:,:,:3]=variation[:,:,None]*np.array([.26,.39,.33])*(.83 if tile==7 else 1)
        if suffix=='MaskMap':
            v[:,:,0]=.06;v[:,:,1]=0;v[:,:,3]=.20
    if suffix=='MaskMap':
        for tile in [3,5]:
            row=tile//4;col=tile%4
            v=a[(3-row)*512:(4-row)*512,col*512:(col+1)*512]
            v[:,:,0]=0;v[:,:,1]=0;v[:,:,3]=.58
    img.pixels.foreach_set(a.ravel());img.filepath_raw=str(tex/('HWL_'+suffix+'.png'));img.file_format='PNG';img.save()
    if suffix!='ControlMask':
        for n in mat.node_tree.nodes:
            if n.type=='TEX_IMAGE' and suffix in n.image.name:
                n.image=img
                if suffix!='BaseColor':img.colorspace_settings.name='Non-Color'
# Retain repaired masonry and facade. Replace only rooftop geometry.
for obj in list(bpy.data.objects):
    if obj.type!='MESH' or not obj.name.startswith(('03','04')):continue
    bm=bmesh.new();bm.from_mesh(obj.data)
    kill=[v for v in bm.verts if v.co.z>H-2.15]
    bmesh.ops.delete(bm,geom=kill,context='VERTS');bm.to_mesh(obj.data);bm.free()
    obj.name='03 retained facade mullions' if obj.name.startswith('03') else '04 retained facade stonework'

def roof_height(x,y):
    fx=max(0,1-abs(x)/(W/2));fy=max(0,1-abs(y)/(D/2))
    # Single continuous cross-hip surface, with shallow barrel crowns.
    bx=math.sqrt(max(0,1-(x/8.0)**2));by=math.sqrt(max(0,1-(y/8.0)**2))
    return H+2.0+5.2*max(fx,fy)+.85*max(bx,by)

def make_roof(lod):
    roof=Builder(f'05 continuous copper roof LOD{lod}')
    for z,extra,t in [(H-.5,.35,.5),(H+.1,.8,.65),(H+1,1.05,.30)]:
        roof.box((0,0,z),(W+extra,D+extra,t),2)
    step=[1.5,3,6][lod]
    xs=np.linspace(-W/2,W/2,math.ceil(W/step)+1)
    ys=np.linspace(-D/2,D/2,math.ceil(D/step)+1)
    for x0,x1 in zip(xs[:-1],xs[1:]):
        for y0,y1 in zip(ys[:-1],ys[1:]):
            # A narrow central glazed winter-garden strip.
            tile=3 if abs((x0+x1)/2)<3.2 and abs((y0+y1)/2)<19 else 2
            roof.face([(x0,y0,roof_height(x0,y0)),(x1,y0,roof_height(x1,y0)),(x1,y1,roof_height(x1,y1)),(x0,y1,roof_height(x0,y1))],tile)
    def edge(side,u,z,out=0):
        if side=='E':return(W/2+out,u,z)
        if side=='W':return(-W/2-out,-u,z)
        if side=='N':return(-u,D/2+out,z)
        return(u,-D/2-out,z)
    for side,length in [('E',D),('W',D),('N',W),('S',W)]:
        us=np.linspace(-length/2,length/2,math.ceil(length/[1.2,2.4,4.8][lod])+1)
        for u,v in zip(us[:-1],us[1:]):
            p=edge(side,u,0);q=edge(side,v,0);h=roof_height(p[0],p[1]);k=roof_height(q[0],q[1])
            pts=[edge(side,u,H+1.15),edge(side,v,H+1.15),edge(side,v,k),edge(side,u,h)]
            roof.face(pts,3);roof.face(list(reversed(pts)),3)
            roof.rod(edge(side,u,H+1.15,.045),edge(side,u,h,.045),[.055,.075,.095][lod],2,4)
            roof.rod(edge(side,u,h+.05),edge(side,v,k+.05),.13,2,6)
        if lod<2:
            for z in np.arange(H+2,H+8,1.2):
                for u,v in zip(us[:-1],us[1:]):
                    p=edge(side,u,0);q=edge(side,v,0)
                    if min(roof_height(p[0],p[1]),roof_height(q[0],q[1]))>z:
                        roof.rod(edge(side,u,z,.06),edge(side,v,z,.06),.045,2,4)
            for u in np.arange(-length/2+1,length/2,1.7):
                roof.rod(edge(side,u,H-2.1,.05),edge(side,u,H+.15,.48),.11,2,5)
        # Fine standing seams follow the roof, never cut through it.
    if lod==0:
        for x in np.arange(-W/2+1,W/2,1.3):
            for y0,y1 in zip(ys[:-1],ys[1:]):
                if abs(x)<3.2 and abs((y0+y1)/2)<19:continue
                roof.rod((x,y0,roof_height(x,y0)+.025),(x,y1,roof_height(x,y1)+.025),.027,7,4)
    return roof.finish()

def make_sculpture(lod):
    sculpt=Builder(f'06 five differentiated owls and acanthus LOD{lod}')
    rings=[8,5,3][lod];segs=[12,8,6][lod]
    def leaf(c,angle,height,width,lean=.25,serrated=True,tile=2):
        dx,dy=math.cos(angle),math.sin(angle);px,py=-dy,dx
        steps=[16,10,5][lod];rows=[]
        for j in range(steps+1):
            t=j/steps;out=height*lean*math.sin(t*math.pi*.8)
            z=c[2]+height*t-height*.09*max(0,(t-.82)/.18)**2
            spread=width*math.sin(math.pi*t)**.65
            if serrated:spread*=1+.22*math.sin(t*10*math.pi)
            rows.append([(c[0]+dx*out+px*spread,c[1]+dy*out+py*spread,z),
                         (c[0]+dx*(out+.20*math.sin(math.pi*t)),c[1]+dy*(out+.20*math.sin(math.pi*t)),z+.09),
                         (c[0]+dx*out-px*spread,c[1]+dy*out-py*spread,z)])
        for a,b in zip(rows[:-1],rows[1:]):
            for k in [0,1]:
                pts=[a[k],a[k+1],b[k+1],b[k]]
                sculpt.face(pts,tile);sculpt.face(pts[::-1],tile)
            if lod<2:sculpt.rod(a[1],b[1],.045,7,4)
    def owl(c,angle,large=False):
        dx,dy=math.cos(angle),math.sin(angle);px,py=-dy,dx
        height=6.096 if large else 3.6576
        # Local coordinates: across, forward, height.
        def p(x,y,z):return(c[0]+px*x+dx*y,c[1]+py*x+dy*y,c[2]+z)
        def ell(q,sz,tile=2):
            start=len(sculpt.v);sculpt.ellipsoid(q,sz,tile,rings,segs)
            sculpt.v[start:]=[p(*v) for v in sculpt.v[start:]]
        def feather(a,b,width,tile=2):
            av=Vector(a);bv=Vector(b);axis=(bv-av).normalized()
            right=axis.cross(Vector((0,1,0))).normalized()
            rows=[];steps=[7,4,3][lod]
            for i in range(steps+1):
                t=i/steps;mid=av.lerp(bv,t);mid.y+=.10*math.sin(math.pi*t)
                w=width*math.sin(math.pi*t)**.65
                rows.append([p(*(mid-right*w)),p(*(mid+Vector((0,.07,0)))),p(*(mid+right*w))])
            for r,s in zip(rows[:-1],rows[1:]):
                for k in [0,1]:
                    pts=[r[k],r[k+1],s[k+1],s[k]]
                    sculpt.face(pts,tile);sculpt.face(pts[::-1],tile)
        # Large owl's 20ft envelope includes tail, head and horns.
        bodytop=4.65 if large else 2.95;headz=5.10 if large else 3.10
        ell((0,-.06,bodytop*.57),((.85 if large else .58),.55,bodytop*.46))
        ell((0,.10,headz),((.72 if large else .46),.44,(.64 if large else .46)))
        if large:
            for sign in [-1,1]:
                # Upper wing coverts and separate overlapping broad primaries.
                feather((sign*.43,-.05,3.55),(sign*3.048,-.03,4.20),.49)
                for j in range([10,7,4][lod]):
                    t=j/max(1,[10,7,4][lod]-1)
                    feather((sign*(.7+1.65*t),.03,3.9+.32*t),
                            (sign*(1.1+1.93*t),.04,2.15+1.55*t),.20)
                feather((sign*.44,.05,5.43),(sign*.69,-.04,6.096),.16)
        else:
            # Barn owls have no ear tufts. Folded wings extend about 8ft.
            for sign in [-1,1]:
                for j in range([7,5,3][lod]):
                    t=j/max(1,[7,5,3][lod]-1)
                    feather((sign*(.42+.16*t),-.05,2.75-.2*t),
                            (sign*(.56+.15*t),-.25,.32+.45*t),.15)
        # Paired facial disks create the heart-shaped barn-owl face.
        for sign in [-1,1]:
            ell((sign*(.30 if large else .18),.43,headz+.02),
                ((.34 if large else .23),.075,(.40 if large else .32)),7)
            ell((sign*(.30 if large else .18),.51,headz+.08),
                ((.08 if large else .055),.055,(.09 if large else .065)),5)
            feather((sign*.07,.53,headz+.35),(sign*(.57 if large else .36),.42,headz+.25),.10)
        sculpt.face([p(-.09,.50,headz),p(.09,.50,headz),p(0,.78,headz-.24)],7)
        if lod<2:
            for iz in range(6 if large else 4):
                z=.65+iz*(.47 if large else .45)
                for ix in range(5):
                    x=(ix-2)*(.23 if large else .17)
                    feather((x,.42,z+.42),(x,.48,z),.13 if large else .10)
        # Book/paper pedestal, feet and hooked talons.
        for sign in [-1,1]:
            a=p(sign*.14,.38,.22);b=p(sign*.58,.41,.12);d=p(sign*.58,-.35,.12);e=p(sign*.14,-.35,.22)
            sculpt.face([a,b,d,e],1)
            sculpt.rod(p(sign*.25,.10,.45),p(sign*.27,.39,.23),.10,7,6)
            for j in [-1,0,1]:
                sculpt.rod(p(sign*.27,.34,.23),p(sign*.27+j*.09,.61,.16),.04,7,5)
        for j in [-1,0,1]:
            feather((j*.18,-.42,1.2),(j*.24,-.48,.08),.16)
    for sx in [-1,1]:
        for sy in [-1,1]:
            x=sx*(W/2-.25);y=sy*(D/2-.25);a=math.atan2(sy,sx)
            owl((x,y,H+1.2),a)
            # Leaves spread along both parapets, with tall curled leaves behind owl.
            for along in [0,1]:
                for i in range([8,6,4][lod]):
                    t=i/max(1,[8,6,4][lod]-1)
                    cx=x-sx*(3.4+9*t)*(1 if along==0 else .55)
                    cy=y-sy*(3.4+9*t)*(1 if along==1 else .55)
                    leaf((cx,cy,H+1.3),a+(1 if along==0 else -1)*(.2+.8*t),
                         10.9*(1-.72*t),1.0+.2*(1-t),-.08)
            for i in [-1,0,1]:
                leaf((x-sx*(3.4+i*.4),y-sy*(3.4-i*.4),H+1.3),a+i*.38,12.192-abs(i)*1.3,1.3,-.10)
    owl((W/2-.75,0,H+7.8),0,True)
    for sy in [-1,1]:
        for i in range(-4,5):
            leaf((i*.65,sy*(D/2-.65),H+7.6),sy*math.pi/2+i*.16,4.4-abs(i)*.60,.60,.22)
    return sculpt.finish()

roof=make_roof(0);sculpture=make_sculpture(0)
base=[o for o in bpy.data.objects if o.type=='MESH' and o.name[:2] in ['01','02','03','04']]
source=base+[roof,sculpture]
scene['creator']=scene['author']='X_Bean_X'
scene['status']='V6 refined continuous roof and differentiated owls; native validation pending'
for o in source:o['author']='X_Bean_X'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source/X_Bean_X_HaroldWashingtonLibrary_v006.blend'))
exports=[]
for lod in [0,1,2]:
    copies=[]
    for src in base:
        o=src.copy();o.data=src.data.copy();o.parent=None;scene.collection.objects.link(o)
        if lod:
            bpy.ops.object.select_all(action='DESELECT');o.select_set(True);bpy.context.view_layer.objects.active=o
            dec=o.modifiers.new('Facade distance simplification','DECIMATE');dec.ratio=[1,.5,.15][lod]
            bpy.ops.object.modifier_apply(modifier=dec.name)
        copies.append(o)
    for src in ([roof,sculpture] if lod==0 else [make_roof(lod),make_sculpture(lod)]):
        if lod==0:
            o=src.copy();o.data=src.data.copy();o.parent=None;scene.collection.objects.link(o)
        else:o=src
        copies.append(o)
    bpy.ops.object.select_all(action='DESELECT')
    for o in copies:o.select_set(True)
    bpy.context.view_layer.objects.active=copies[0];bpy.ops.object.join();o=bpy.context.object
    name='HaroldWashingtonLibraryV6'+(f'_LOD{lod}' if lod else '')
    o.name=o.data.name=name;o['Author']='X_Bean_X'
    tri=o.modifiers.new('Triangulate','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
    # Remove numerical zero-area triangles without decimating roof silhouettes.
    bm=bmesh.new();bm.from_mesh(o.data)
    bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001)
    bm.to_mesh(o.data);bm.free()
    pts=np.array([v.co for v in o.data.vertices])
    assert np.isfinite(pts).all() and pts[:,2].min()>-.01
    path=stage/(name+'.fbx')
    bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'MESH'},global_scale=1,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='FACE',use_tspace=True,add_leaf_bones=False,bake_anim=False,path_mode='AUTO',use_custom_props=True)
    exports.append({'lod':lod,'file':path.name,'vertices':len(o.data.vertices),'triangles':len(o.data.polygons),'bounds_min':pts.min(axis=0).tolist(),'bounds_max':pts.max(axis=0).tolist()})
    for suffix in ['BaseColor','MaskMap','Normal','ControlMask']:shutil.copy2(tex/('HWL_'+suffix+'.png'),stage/(name+'_'+suffix+'.png'))
    bpy.data.objects.remove(o,do_unlink=True)
(R/'Validation/mesh_export_v006.json').write_text(json.dumps({'author':'X_Bean_X','meshes':exports,'roof':'continuous cross-hip surface with shallow barrel crowns','owls':'four 3.6576m barn owls and one 6.096m great horned owl envelope; sculptural approximation','lods':'same roof function and ornament placement at every distance'},indent=2))
cam=scene.camera
def aim(p):cam.rotation_euler=(Vector(p)-cam.location).to_track_quat('-Z','Y').to_euler()
scene.cycles.samples=32
for name,location,target,scale in [
    ('v006_southeast',(145,-190,130),(0,0,26),170),
    ('v006_roof',(105,-140,155),(0,0,42),140),
    ('v006_corner_owl',(62,-82,63),(W/2-3,-D/2+3,46),21),
    ('v006_state_owl',(65,-13,55),(W/2,0,50),13)]:
    cam.location=location;cam.data.ortho_scale=scale;aim(target)
    scene.render.filepath=str(R/'Renders'/(name+'.png'));bpy.ops.render.render(write_still=True)
print('V006_COMPLETE',json.dumps(exports),flush=True)
