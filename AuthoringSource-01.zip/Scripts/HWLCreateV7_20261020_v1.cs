using System;using System.IO;using System.Linq;using System.Collections.Generic;
using ChicagoBuildBridge;using Colossal;using Colossal.UI;using Colossal.IO.AssetDatabase;
using Game.Prefabs;using Game.Prefabs.Effects;using Newtonsoft.Json.Linq;
using Unity.Collections;using Unity.Entities;using Unity.Mathematics;using UnityEngine;
namespace ChicagoBuildExtensions{public static class Entry{
public static object Run(BridgeSystem b,JObject c){
var ps=b.World.GetExistingSystemManaged<PrefabSystem>();RenderPrefab mesh=null;
using(var q=b.EntityManager.CreateEntityQuery(ComponentType.ReadOnly<PrefabData>()))
using(var es=q.ToEntityArray(Allocator.Temp))foreach(var e in es){
var name=ps.GetPrefabName(e);if(name=="HaroldWashingtonLibraryV7")throw new Exception("V7 already exists; inspect rather than repeat");
if(name=="HaroldWashingtonLibraryV7 Mesh")mesh=ps.GetPrefab<RenderPrefab>(e);}
if(mesh==null)throw new Exception("Imported V7 render mesh missing");
if(!ps.TryGetPrefab(new PrefabID("BuildingPrefab","CN_ModernLibrary"),out var source))throw new Exception("Native library missing");
if(!ps.TryGetPrefab(new PrefabID("EffectPrefab","GardenLightSource03"),out var originalLight))throw new Exception("Native light missing");
const string folder="X_Bean_X/HaroldWashingtonLibraryV7";
var light=PrefabBase.Create<EffectPrefab>("XBeanXHWLLightV7");
light.m_Conditions=((EffectPrefab)originalLight).m_Conditions;light.m_DisableDistanceCulling=false;
foreach(var co in originalLight.components)light.AddComponentFrom(co);
var le=light.GetComponent<LightEffect>();le.m_Range=11f;le.m_ColorTemperature=3000f;le.m_LightDimmer=1f;le.m_UseVolumetric=false;
var la=AssetDatabase.user.AddAsset(AssetDataPath.Create(folder,light.name),light);la.Save();ps.AddPrefab(light);
var p=PrefabBase.Create<BuildingPrefab>("HaroldWashingtonLibraryV7");
var copy=new HashSet<string>{"ServiceConsumption","ResearchFacility","CityEffects","ServiceObject","PlaceableObject","Workplace","CityServiceBuilding","UIObject","Pollution","Attraction","LeisureProvider","LocalEffects"};
foreach(var co in source.components)if(copy.Contains(co.GetType().Name))p.AddComponentFrom(co);
// The imported FBX has reversed horizontal handedness. Rotate render geometry,
// while retaining native +Z as the street/entrance direction.
p.m_Meshes=new[]{new ObjectMeshInfo{m_Mesh=mesh,m_Position=float3.zero,m_Rotation=quaternion.RotateY(math.radians(90f))}};
p.m_LotWidth=14;p.m_LotDepth=8;p.m_AccessType=((BuildingPrefab)source).m_AccessType;
var entry=source.GetComponent<ObjectSubObjects>().m_SubObjects.Single(x=>x.m_Object.Has<SpawnLocation>());
entry.m_Position=new float3(0,0,31.7f);entry.m_Rotation=quaternion.RotateY(math.PI);entry.m_ParentMesh=0;entry.m_GroupIndex=0;entry.m_Probability=100;
p.AddOrGetComponent<ObjectSubObjects>().m_SubObjects=new[]{entry};
var fx=p.AddOrGetComponent<EffectSource>();fx.m_Effects=new List<EffectSource.EffectSettings>();
foreach(float x in new[]{-35f,-17.5f,0f,17.5f,35f})
fx.m_Effects.Add(new EffectSource.EffectSettings{m_Effect=light,m_PositionOffset=new float3(x,5.6f,32.2f),m_ParentMesh=-1,m_Intensity=1});
foreach(float x in new[]{-53f,53f})foreach(float z in new[]{-20f,0f,20f})
fx.m_Effects.Add(new EffectSource.EffectSettings{m_Effect=light,m_PositionOffset=new float3(x,5.6f,z),m_ParentMesh=-1,m_Intensity=1});
var u=p.AddOrGetComponent<Unlockable>();u.m_RequireAll=new PrefabBase[0];u.m_RequireAny=new PrefabBase[0];u.m_IgnoreDependencies=true;
p.AddOrGetComponent<ObsoleteIdentifiers>().m_PrefabIdentifiers=new[]{new PrefabIdentifierInfo{m_Type="BuildingPrefab",m_Name=p.name}};
var icon=AssetDatabase.user.AddAsset<ImageAsset>(AssetDataPath.Create(folder,"HWL_X_Bean_X_V7.png",true));
using(var dst=icon.GetWriteStream())using(var src=File.OpenRead(@"H:\Games\GPT, Chicago AI Project\ACM - Buildings\WIP\Harold Washington Library\Renders\v007_southeast.png"))src.CopyTo(dst);
icon.Save();p.GetComponent<UIObject>().m_Icon=icon.ToGlobalUri();p.GetComponent<UIObject>().m_Priority=409;
p.AddOrGetComponent<Localization>().m_LocalizationID=p.name;
var a=AssetDatabase.user.AddAsset(AssetDataPath.Create(folder,p.name),p);a.Save();ps.AddPrefab(p);ps.Update();
var loc=AssetDatabase.user.AddAsset<LocaleAsset>(AssetDataPath.Create(folder,"en-US"));
var strings=new Dictionary<string,string>{
{"Assets.NAME["+p.name+"]","Harold Washington Library Center"},
{"Assets.DESCRIPTION["+p.name+"]","Chicago's Harold Washington Library Center. Copper roof, four barn owls and the State Street great horned owl. Author: X_Bean_X. Library and research service; 60 workplaces."}};
loc.SetData(new LocaleData("en-US",strings,new Dictionary<string,int>()),SystemLanguage.English,"English");loc.Save();Game.SceneFlow.GameManager.instance.localizationManager.AddSource("en-US",loc);
return new{status="created",author="X_Bean_X",asset=a.path,mesh=mesh.name,renderYaw=90,entrance="+Z",lights=fx.m_Effects.Count,icon=p.GetComponent<UIObject>().m_Icon,locale=loc.path};
}}}

