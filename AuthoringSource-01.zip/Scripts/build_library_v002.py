"""Second architectural pass; X_Bean_X. Photo-derived roof details remain approximate.

Uses the retained v001 generator as a reproducible baseline. Writes a new editable
source and new renders; refreshes the import candidates for native validation.
"""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
code = (root/'Scripts/build_library.py').read_text()
code = code.replace('X_Bean_X_HaroldWashingtonLibrary_v001.blend', 'X_Bean_X_HaroldWashingtonLibrary_v002.blend')
code = code.replace('_draft.png', '_v002.png')
code = code.replace("orn=Builder('04 provisional foliage and five owl ornaments')", "orn=Builder('04 sculpted foliage and five owl ornaments')")
# The prior broadly worded naming claim exceeded the observed evidence.
code = code.replace('Native importer splits underscores for suffix parsing.', 'The isolated audit probe failed ParseName with its original multi-part stem.')
code = code.replace('stylized foliage meshes require sculpted refinement.', 'Photo-derived sculpted foliage and owl motifs are approximations, not scanned replicas.')
insert = r'''
# Standing seams and shallow curved roof caps, reconstructed from the aerial photo.
# Keep these inside the measured wall plan; no enlargement of the site footprint.
for direction in ['NS','EW']:
    halfspan = W*.17 if direction=='NS' else D*.12
    halflen = D*.28 if direction=='NS' else W*.28
    def cap(u,v):
        z=top+.18+2.0*(max(0,1-(u/halfspan)**2)**.5)
        return (u,v,z) if direction=='NS' else (v,u,z)
    for i in range(24):
        u0=-halfspan+2*halfspan*i/24;u1=-halfspan+2*halfspan*(i+1)/24
        metal.face([cap(u0,-halflen),cap(u1,-halflen),cap(u1,halflen),cap(u0,halflen)],2)
        metal.rod(cap(u0,-halflen),cap(u0,halflen),.035,2,4)
    for v in np.arange(-halflen,halflen+1,2.5):
        for i in range(24):
            metal.rod(cap(-halfspan+2*halfspan*i/24,v),cap(-halfspan+2*halfspan*(i+1)/24,v),.032,2,4)
# Repeated curled anthemion molding along the outer glass-gable edges.
for side,length in [('E',D),('N',W),('S',W),('W',D)]:
    for u in np.arange(-length/2+1,length/2-1,1.4):
        z=roofbase+1.2+(peak-roofbase-1.2)*(1-abs(u)/(length/2))
        for sign in [-1,1]:
            last=None
            for a in np.linspace(0,math.pi*1.7,10):
                rr=.38*(1-a/(math.pi*2.2))
                p=pface(side,u+sign*(.28+rr*math.cos(a)),z+.30+rr*math.sin(a),.61)
                if last is not None:orn.rod(last,p,.065,2,5)
                last=p
'''
code = code.replace('\ndef leaf(c,angle,height,width):', insert+'\ndef leaf(c,angle,height,width):')
# More articulated leaves: folded, scalloped edges and raised midribs.
code = code.replace('for j in range(8):\n        ts=[j/8,(j+1)/8]', 'for j in range(12):\n        ts=[j/12,(j+1)/12]')
code = code.replace('out=height*.18*math.sin(t*math.pi*.8)', 'out=height*.24*math.sin(t*math.pi*1.12)')
code = code.replace('for k in [0,1]:orn.face([rows[0][k],rows[0][k+1],rows[1][k+1],rows[1][k]],2)', '''for k in [0,1]:orn.face([rows[0][k],rows[0][k+1],rows[1][k+1],rows[1][k]],2)
        orn.rod(rows[0][1],rows[1][1],.045,2,5)''')
insert2 = r'''
# Dense scrollwork at all seven crest positions. Entire geometry stays within
# the existing cornice envelope; decorative proportions are photo estimates.
def scroll_cluster(c,front,scale):
    dx,dy=math.cos(front),math.sin(front);px,py=-dy,dx
    for tier in range(3):
        for sign in [-1,1]:
            last=None
            for a in np.linspace(0,math.pi*3,28):
                rad=scale*(.65-tier*.12)*(1-a/(math.pi*3.5))
                u=sign*(scale*(.65+tier*.26)+rad*math.cos(a))
                z=c[2]+scale*(.4+tier*.56)+rad*math.sin(a)
                p=(c[0]+px*u+dx*.06,c[1]+py*u+dy*.06,z)
                if last is not None:orn.rod(last,p,scale*.055,2,6)
                last=p
    for sign in [-1,1]:
        for i in range(6):
            leaf((c[0]+px*sign*(.5+i*.37)*scale,c[1]+py*sign*(.5+i*.37)*scale,c[2]+scale*.15),front+sign*.5,scale*(2.4-.24*i),scale*.28)
for sx in [-1,1]:
    for sy in [-1,1]:
        c=(sx*(W/2-3.5),sy*(D/2-3.5),H+1.25)
        scroll_cluster(c,math.atan2(sy,sx),1.5)
for sy in [-1,1]:scroll_cluster((0,sy*(D/2-1),H+7.8),sy*math.pi/2,1.35)
scroll_cluster((W/2-1.6,0,H+8.1),0,1.3)
'''
code = code.replace('details=detail.finish();roof=metal.finish();ornaments=orn.finish()', insert2+'\ndetails=detail.finish();roof=metal.finish();ornaments=orn.finish()')
exec(compile(code,str(root/'Scripts/build_library.py'),'exec'))
