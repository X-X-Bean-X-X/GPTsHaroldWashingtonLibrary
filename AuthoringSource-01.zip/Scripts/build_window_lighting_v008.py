import bpy,math,json,random
from pathlib import Path
R=Path(__file__).resolve().parents[1]
OUT=R/'ImportLightingV008'; OUT.mkdir(exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
W=63.42554414;D=109.24487609;H=39.624
panes=[]
def pface(side,u,z,out):
 return {'E':(W/2+out,u,z),'W':(-W/2-out,-u,z),'N':(-u,D/2+out,z),'S':(u,-D/2-out,z)}[side]
def clip(poly,axis,value,greater):
 out=[]
 for a,b in zip(poly,poly[1:]+poly[:1]):
  ina=(a[axis]>=value) if greater else (a[axis]<=value)
  inb=(b[axis]>=value) if greater else (b[axis]<=value)
  if ina:out.append(a)
  if ina!=inb:
   t=(value-a[axis])/(b[axis]-a[axis]);out.append(tuple(a[k]+t*(b[k]-a[k]) for k in range(2)))
 return out

def add(side,kind,col,row,pts):
 if len(pts)<3:return
 # Coherent small clusters, with independent seeds for every facade and bay.
 key=f'{side}/{kind}/{col//2}/{row//2}'
 import hashlib
 group=int.from_bytes(hashlib.sha256(key.encode()).digest()[:4],'little')%10
 panes.append(dict(id=len(panes),side=side,kind=kind,col=col,row=row,group=group,vertices=pts))
for side,length,count in [('E',D,5),('N',W,3),('S',W,3)]:
 centers=[-length*.32+length*.64*i/(count-1) for i in range(count)]
 for bay,u in enumerate(centers):
  poly=[(-3.6,10.1),(3.6,10.1)]+[(3.6*math.cos(i*math.pi/64),32.8+3.6*math.sin(i*math.pi/64)) for i in range(65)]
  xs=[-3.6,-2.3,0,2.3,3.6];zs=[10.1]+[10.2+2.8*i for i in range(10)]+[36.4]
  zs=sorted(set(zs))
  for col,(a,b) in enumerate(zip(xs,xs[1:])):
   for row,(c,d) in enumerate(zip(zs,zs[1:])):
    if d-c<.25:continue
    q=poly
    for ax,v,g in [(0,a+.115,True),(0,b-.115,False),(1,c+.115,True),(1,d-.115,False)]:
     q=clip(q,ax,v,g)
     if not q:break
    if len(q)>=3:add(side,'tall-arched-pane',bay*4+col,row,[pface(side,u+x,z,.268) for x,z in q])
  for n,dx in enumerate([-5.8,5.8]):
   q=[(-.46,6.13),(.46,6.13)]+[(.46*math.cos(i*math.pi/16),7.65+.46*math.sin(i*math.pi/16)) for i in range(17)]
   add(side,'small-arched-window',bay*2+n,0,[pface(side,u+dx+x,z,.188) for x,z in q])
# West curtain wall: model has 35 columns and 13 rows of discrete 2.8m panes.
u=-D/2+2;col=0
while u<D/2-1:
 z=2;row=0
 while z<H-1:
  add('W','curtain-wall-pane',col,row,[pface('W',a,b,.178) for a,b in [(u+.06,z+.06),(u+2.74,z+.06),(u+2.74,z+2.74),(u+.06,z+2.74)]])
  z+=3;row+=1
 u+=3;col+=1
# Roof clerestory: clip each pane to the actual roof edge and horizontal rails.
def height(x,y):
 return H+2+5.2*max(max(0,1-abs(x)/(W/2)),max(0,1-abs(y)/(D/2)))+.85*max(math.sqrt(max(0,1-(x/8)**2)),math.sqrt(max(0,1-(y/8)**2)))
for side,length in [('E',D),('W',D),('N',W),('S',W)]:
 n=math.ceil(length/1.2);us=[-length/2+length*i/n for i in range(n+1)]
 for col,(a,b) in enumerate(zip(us,us[1:])):
  pa=pface(side,a,0,0);pb=pface(side,b,0,0);ha=height(pa[0],pa[1]);hb=height(pb[0],pb[1])
  poly=[(a,H+1.15),(b,H+1.15),(b,hb),(a,ha)]
  zs=[H+1.15]+[H+2+i*1.2 for i in range(5)]+[H+8.1]
  for row,(c,d) in enumerate(zip(zs,zs[1:])):
   q=poly
   for ax,v,g in [(0,a+.07,True),(0,b-.07,False),(1,c+.065,True),(1,d-.065,False)]:
    q=clip(q,ax,v,g)
    if not q:break
   if len(q)>=3:add(side,'roof-clerestory-pane',col,row,[pface(side,u,z,.018) for u,z in q])
# The winter-garden roof strip is exterior architectural glazing, excluded from interior-window patterns.
patterns=[[0,2,5,7],[1,2,4,8],[0,3,6,9]]
counts=[sum(p['group'] in s for p in panes) for s in patterns]
assert all(.3<=n/len(panes)<=.6 for n in counts),(len(panes),counts)
for g in range(10):
 name=f'XBeanXHWLWindowsG{g}V8';folder=OUT/name;folder.mkdir(exist_ok=True)
 vv=[];ff=[]
 for p in panes:
  if p['group']!=g:continue
  start=len(vv);vv+=p['vertices'];face=tuple(range(start,len(vv)));ff.append(face)
 mesh=bpy.data.meshes.new(name);mesh.from_pydata(vv,[],ff);mesh.update()
 # Explicit outward normals for all four facades.
 import bmesh
 bm=bmesh.new();bm.from_mesh(mesh)
 for f in bm.faces:
  c=f.calc_center_median()
  if c.x*f.normal.x+c.y*f.normal.y<0:f.normal_flip()
 bm.to_mesh(mesh);bm.free()
 uv=mesh.uv_layers.new(name='UVMap')
 for p in mesh.polygons:
  for j,k in enumerate(p.loop_indices):uv.data[k].uv=((j%2)*.8+.1,((j//2)%2)*.8+.1)
 mat=bpy.data.materials.new(name);mat.diffuse_color=(.055,.075,.065,1);mesh.materials.append(mat)
 obj=bpy.data.objects.new(name,mesh);bpy.context.scene.collection.objects.link(obj)
 bpy.ops.object.select_all(action='DESELECT');obj.select_set(True);bpy.context.view_layer.objects.active=obj
 tri=obj.modifiers.new('Triangulation','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
 bpy.ops.export_scene.fbx(filepath=str(folder/(name+'.fbx')),use_selection=True,object_types={'MESH'},global_scale=1,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='FACE',use_tspace=True,add_leaf_bones=False,bake_anim=False,path_mode='AUTO')
 for suffix,color in [('BaseColor',(.055,.075,.065,1)),('MaskMap',(0,0,0,.5)),('Normal',(.5,.5,1,1)),('ControlMask',(0,0,0,1)),('Emissive',(1,1,1,1))]:
  im=bpy.data.images.new(name+suffix,width=64,height=64,alpha=True)
  im.colorspace_settings.name='Non-Color';im.pixels.foreach_set(list(color)*4096);im.filepath_raw=str(folder/(name+'_'+suffix+'.png'));im.file_format='PNG';im.save()
bpy.context.scene['author']='X_Bean_X'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source/X_Bean_X_HWL_WindowLights_v008.blend'))
report=dict(author='X_Bean_X',modeledWindowCount=len(panes),groupCounts=[sum(p['group']==g for p in panes) for g in range(10)],patterns=patterns,litWindowCounts=counts,litWindowPercent=[100*n/len(panes) for n in counts],authoredStageSeconds=[37,53,71],cycleSeconds=161,panes=panes,exclusions=['Entrance doors and exterior fixtures','Winter-garden skylight treated as exterior architectural glazing'])
(R/'Validation/window-layout-v008.json').write_text(json.dumps(report,indent=2))
print('WINDOW_LIGHTING_READY',len(panes),counts,flush=True)
