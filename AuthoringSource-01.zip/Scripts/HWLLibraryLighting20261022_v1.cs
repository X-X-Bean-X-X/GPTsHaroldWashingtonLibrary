using System;using System.IO;using System.Linq;using System.Collections.Generic;using ChicagoBuildBridge;using Game.Prefabs;using Game.AssetPipeline;using Game.UI.Editor;using Colossal.AssetPipeline;using Colossal.IO.AssetDatabase;using Newtonsoft.Json;using Newtonsoft.Json.Linq;using UnityEngine;using Unity.Mathematics;
namespace ChicagoBuildExtensions{public static class Entry{
const string Root=@"H:\Games\GPT, Chicago AI Project\ACM - Buildings\WIP\Harold Washington Library";
const string Folder="X_Bean_X/HWLLibraryLightingV8";
class Factory:IPrefabFactory{public List<PrefabBase> prefabs=new List<PrefabBase>();public T CreatePrefab<T>(string sourcePath,string assetName,int lodLevel)where T:PrefabBase{var p=PrefabBase.Create<T>(assetName);prefabs.Add(p);return p;}}
public static object Run(BridgeSystem b,JObject c){var report=Root+@"\Validation\lighting-native-v008.json";if(File.Exists(report))throw new Exception("Already requested; inspect result");File.WriteAllText(report,"{\"status\":\"running\"}");Start(b,report);return new{status="queued",report};}
static async void Start(BridgeSystem b,string report){try{
var ps=b.World.GetExistingSystemManaged<PrefabSystem>();if(!ps.TryGetPrefab(new PrefabID("BuildingPrefab","HaroldWashingtonLibraryV7"),out var source))throw new Exception("Library V7 missing");
AssetImportPipeline.targetDatabase=AssetDatabase.user;AssetImportPipeline.importSeed="b8928a337127b88f";var f=new Factory();await AssetImportPipeline.ImportPath(Root,new[]{"ImportLightingV008"},ImportMode.All|ImportMode.Forced,false,null,f);
if(f.prefabs.Count!=10||f.prefabs.Any(x=>!(x is RenderPrefab)))throw new Exception("Expected 10 window renders");
var patterns=new[]{new[]{0,2,5,7},new[]{1,2,4,8},new[]{0,3,6,9}};
var renders=new List<RenderPrefab>();var rows=new List<object>();
for(int g=0;g<10;g++){
var rp=(RenderPrefab)f.prefabs.Single(x=>x.name=="XBeanXHWLWindowsG"+g+"V8 Mesh");
var ep=rp.AddOrGetComponent<EmissiveProperties>();ep.m_MultiLights=null;ep.m_SingleLights=new List<EmissiveProperties.SingleLightMapping>{new EmissiveProperties.SingleLightMapping{materialId=0,purpose=EmissiveProperties.Purpose.DecorativeLight,previewState=true,color=new Color(1,.86f,.65f,1),colorOff=Color.black,intensity=.018f,responseTime=0,animationIndex=0}};
float[] times={0,37f/161f,90f/161f,1};var keys=Enumerable.Range(0,4).Select(s=>new Keyframe(times[s],patterns[s%3].Contains(g)?1:0,float.PositiveInfinity,float.PositiveInfinity)).ToArray();var curve=new AnimationCurve(keys);curve.preWrapMode=WrapMode.Loop;curve.postWrapMode=WrapMode.Loop;
ep.m_AnimationCurves=new List<EmissiveProperties.AnimationProperties>{new EmissiveProperties.AnimationProperties{m_Duration=161,m_Curve=curve}};
var a=AssetDatabase.user.AddAsset(AssetDataPath.Create(Folder,rp.name),rp);a.Save();renders.Add(rp);rows.Add(new{name=rp.name,asset=a.path,vertices=rp.vertexCount,indices=rp.indexCount,meshes=rp.meshCount,surfaces=rp.surfaceAssets.Select(x=>x.path).ToArray()});}
var building=(BuildingPrefab)source;var p=PrefabBase.Create<BuildingPrefab>(building.name);foreach(var co in building.components)p.AddComponentFrom(co);p.m_LotWidth=building.m_LotWidth;p.m_LotDepth=building.m_LotDepth;p.m_AccessType=building.m_AccessType;
p.m_Meshes=building.m_Meshes.Concat(renders.Select(rp=>new ObjectMeshInfo{m_Mesh=rp,m_Position=float3.zero,m_Rotation=quaternion.RotateY(math.radians(90f))})).ToArray();
var pa=AssetDatabase.user.AddAsset(AssetDataPath.Create(Folder,p.name),p);pa.Save();
var dc=new DependencyCollector();foreach(var rp in renders)dc.AddAsset(rp.asset);var aa=dc.CompileAllAssets();
File.WriteAllText(report,JsonConvert.SerializeObject(new{status="packaging",rootPrefab=pa.path,rows,assets=aa.Select(a=>a.path).ToArray(),mods=dc.modDependencies,dlc=dc.dlcDependencies},Formatting.Indented));
PackageHelper.OnCreatePackage(dc,null,(package,success)=>File.WriteAllText(report,JsonConvert.SerializeObject(new{status=success?"completed":"failed",rootPrefab=pa.path,bundle=package?.path,rows,mods=dc.modDependencies,dlc=dc.dlcDependencies},Formatting.Indented)));
}catch(Exception e){File.WriteAllText(report,JsonConvert.SerializeObject(new{status="failed",error=e.ToString()}));}}}}
