"""Editable architectural production draft, X_Bean_X.
Horizontal sizing comes from site_measurements.json. Heights and carved ornament
are explicitly provisional; this is not a certified game-ready asset.
Run Blender background with --python this_file.
"""
import bpy,bmesh,math,json,random,shutil
from pathlib import Path
from mathutils import Vector
from io_scene_fbx import parse_fbx
import numpy as np
R=Path(__file__).resolve().parents[1]
for name in ['Source','Renders','Export','Validation']: (R/name).mkdir(exist_ok=True)
stage=R/'Import'/'HaroldWashingtonLibrary';stage.mkdir(parents=True,exist_ok=True)
S=json.loads((R/'Evidence/site_measurements.json').read_text())
W=S['target_m']['east_west'];D=S['target_m']['north_south'];H=39.624
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene['creator']='X_Bean_X';scene['author']='X_Bean_X';scene['status']='Architectural production draft; height and ornament provisional; native import untested'
scene['measured_footprint_m']=f'{W:.6f} x {D:.6f}'
scene['provisional_masonry_cornice_height_m']=H
mat=bpy.data.materials.new('X_Bean_X_HWL_Atlas');mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF');links=mat.node_tree.links
for suffix in ['BaseColor','MaskMap','Normal']:
    n=mat.node_tree.nodes.new('ShaderNodeTexImage');n.image=bpy.data.images.load(str(R/'Textures'/('HWL_'+suffix+'.png')))
    if suffix!='BaseColor':n.image.colorspace_settings.name='Non-Color'
    if suffix=='BaseColor': links.new(n.outputs['Color'],bs.inputs['Base Color'])
    if suffix=='MaskMap':
        sep=mat.node_tree.nodes.new('ShaderNodeSeparateColor');links.new(n.outputs['Color'],sep.inputs['Color']);links.new(sep.outputs['Red'],bs.inputs['Metallic'])
        inv=mat.node_tree.nodes.new('ShaderNodeMath');inv.operation='SUBTRACT';inv.inputs[0].default_value=1;links.new(n.outputs['Alpha'],inv.inputs[1]);links.new(inv.outputs[0],bs.inputs['Roughness'])
    if suffix=='Normal':
        norm=mat.node_tree.nodes.new('ShaderNodeNormalMap');norm.inputs['Strength'].default_value=.32;links.new(n.outputs['Color'],norm.inputs['Color']);links.new(norm.outputs[0],bs.inputs['Normal'])
class Builder:
    def __init__(self,name): self.name=name;self.v=[];self.f=[];self.m=[]
    def face(self,pts,m):
        off=len(self.v);self.v.extend(pts);self.f.append(tuple(range(off,off+len(pts))));self.m.append(m)
    def box(self,c,size,m=0,grid=False):
        c=np.array(c);sz=np.array(size)/2
        for axis in range(3):
            other=[a for a in range(3) if a!=axis]
            for side in [-1,1]:
                nu=max(1,math.ceil(size[other[0]]/4)) if grid else 1;nv=max(1,math.ceil(size[other[1]]/4)) if grid else 1
                for u in range(nu):
                    for v in range(nv):
                        pts=[]
                        for du,dv in [(0,0),(1,0),(1,1),(0,1)]:
                            p=c.copy();p[axis]+=side*sz[axis];p[other[0]]+=((u+du)/nu*2-1)*sz[other[0]];p[other[1]]+=((v+dv)/nv*2-1)*sz[other[1]];pts.append(tuple(p))
                        self.face(pts,m)
    def rod(self,a,b,r,m=2,n=6):
        a=Vector(a);b=Vector(b);z=(b-a).normalized();x=z.cross(Vector((0,0,1)))
        if x.length<.01:x=z.cross(Vector((0,1,0)))
        x.normalize();y=z.cross(x);rr=[x*math.cos(i*math.tau/n)*r+y*math.sin(i*math.tau/n)*r for i in range(n)]
        for i in range(n):self.face([tuple(a+rr[i]),tuple(a+rr[(i+1)%n]),tuple(b+rr[(i+1)%n]),tuple(b+rr[i])],m)
        self.face([tuple(a+v) for v in rr],m);self.face([tuple(b+v) for v in reversed(rr)],m)
    def ellipsoid(self,c,sz,m=2,rings=5,segs=8):
        for j in range(rings):
            for i in range(segs):
                ps=[]
                for dj,di in [(0,0),(0,1),(1,1),(1,0)]:
                    a=(i+di)*math.tau/segs;b=-math.pi/2+(j+dj)*math.pi/rings
                    ps.append((c[0]+sz[0]*math.cos(b)*math.cos(a),c[1]+sz[1]*math.cos(b)*math.sin(a),c[2]+sz[2]*math.sin(b)))
                self.face(ps,m)
    def finish(self):
        mesh=bpy.data.meshes.new(self.name);mesh.from_pydata(self.v,[],self.f);mesh.materials.append(mat);mesh.update()
        uv=mesh.uv_layers.new(name='UVMap')
        for p,mi in zip(mesh.polygons,self.m):
            pts=np.array([mesh.vertices[mesh.loops[l].vertex_index].co for l in p.loop_indices]);ext=pts.max(axis=0)-pts.min(axis=0);axes=np.argsort(ext)[-2:]
            lo=pts[:,axes].min(axis=0);span=np.maximum(pts[:,axes].max(axis=0)-lo,.001)
            for l,pnt in zip(p.loop_indices,pts):
                t=(pnt[axes]-lo)/span;uv.data[l].uv=((mi%4+.012+t[0]*.976)/4,1-(mi//4+1)/4+.003+t[1]*.244)
        obj=bpy.data.objects.new(self.name,mesh);scene.collection.objects.link(obj);obj['creator']='X_Bean_X'
        bm=bmesh.new();bm.from_mesh(mesh);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.00001);bmesh.ops.dissolve_degenerate(bm,edges=list(bm.edges),dist=.000001);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(mesh);bm.free();return obj
body=Builder('01 masonry shell and stone courses')
body.box((0,0,H/2),(W,D,H),0,True)
body.box((0,0,4.5),(W+.12,D+.12,9),1,True)
for z in [1,3,9.3,14.8,20.3,25.8,31.3,36.8]:body.box((0,0,z),(W+.20,D+.20,.26 if z>9.3 else .35),1)
body.box((0,0,9.65),(W+.5,D+.5,.38),1)
shell=body.finish()
detail=Builder('02 arched facades and entrance surrounds')
metal=Builder('03 cornice roof glazing and mullions')
orn=Builder('04 provisional foliage and five owl ornaments')
def pface(side,u,z,out=0):
    if side=='E':return (W/2+out,u,z)
    if side=='N':return (-u,D/2+out,z)
    if side=='S':return (u,-D/2-out,z)
    return (-W/2-out,-u,z)
def arch(side,u,bottom,spring,r,out,m,builder):
    pts=[pface(side,u-r,bottom,out),pface(side,u+r,bottom,out)]
    pts += [pface(side,u+r*math.cos(a),spring+r*math.sin(a),out) for a in np.linspace(0,math.pi,17)]
    builder.face(pts,m)
def arcring(side,u,bottom,spring,r,width,out,m):
    for a,b in zip(np.linspace(0,math.pi,25)[:-1],np.linspace(0,math.pi,25)[1:]):
        detail.face([pface(side,u+r*math.cos(a),spring+r*math.sin(a),out),pface(side,u+r*math.cos(b),spring+r*math.sin(b),out),pface(side,u+(r+width)*math.cos(b),spring+(r+width)*math.sin(b),out+.15),pface(side,u+(r+width)*math.cos(a),spring+(r+width)*math.sin(a),out+.15)],m)
    for sign in [-1,1]:
        detail.face([pface(side,u+sign*r,bottom,out),pface(side,u+sign*r,spring,out),pface(side,u+sign*(r+width),spring,out+.15),pface(side,u+sign*(r+width),bottom,out+.15)],m)
def mullion(side,u,z0,z1,r=.10):metal.rod(pface(side,u,z0,.35),pface(side,u,z1,.35),r,4)
for side,length,count in [('E',D,5),('N',W,3),('S',W,3)]:
    centers=np.linspace(-length*.32,length*.32,count)
    for u in centers:
        radius=3.6;spring=32.8;bottom=10.1
        arch(side,u,bottom,spring,radius,.25,3,detail)
        for layer in range(4):arcring(side,u,bottom,spring,radius+layer*.32,.29,.36+layer*.18,0)
        for dx in [-2.3,0,2.3]:
            top=spring+math.sqrt(radius**2-dx**2);mullion(side,u+dx,bottom,top,.095)
        for z in np.arange(10.2,36,2.8):
            rr=radius if z<=spring else math.sqrt(max(0,radius**2-(z-spring)**2))
            metal.rod(pface(side,u-rr,z,.35),pface(side,u+rr,z,.35),.095,4)
        # Arched street-level entrance/display bay.
        arch(side,u,.05,3.4,2.15,.16,5,detail);arcring(side,u,.05,3.4,2.15,.65,.22,1)
        for dx in [-1.25,0,1.25]:metal.rod(pface(side,u+dx,.1,.3),pface(side,u+dx,4.7,.3),.085,6)
        metal.rod(pface(side,u-2.1,2.8,.3),pface(side,u+2.1,2.8,.3),.09,6)
        for dx in [-5.8,5.8]:
            arch(side,u+dx,6.1,7.65,.50,.17,5,detail)
            for j in [-.3,-.15,0,.15,.3]:metal.rod(pface(side,u+dx+j,6.1,.23),pface(side,u+dx+j,8,.23),.03,4)
    # Suspended terracotta ornament between tall window bays.
    pilasters=[-length*.46]+[(float(a)+float(b))/2 for a,b in zip(centers[:-1],centers[1:])]+[length*.46]
    for u in pilasters:
        for z in np.arange(10.5,35,2.6):
            orn.ellipsoid(pface(side,u,z,.28),(.22,.22,.5),1,3,6)
        for j in range(10):
            v=-1.7+j*.38;orn.ellipsoid(pface(side,u+v,35.1-.6*math.sin(j*math.pi/9),.45),(.24,.24,.22),1,3,6)
# Glass west facade: distinct from the three brick elevations.
for u in np.arange(-D/2+2,D/2-1,3):
    for z in np.arange(2,H-1,3):
        detail.face([pface('W',u,z,.16),pface('W',u+2.8,z,.16),pface('W',u+2.8,z+2.8,.16),pface('W',u,z+2.8,.16)],5)
for u in np.arange(-D/2+2,D/2,3):metal.rod(pface('W',u,1,.24),pface('W',u,H,.24),.10,4)
for z in np.arange(1,H,3):metal.rod(pface('W',-D/2+1,z,.24),pface('W',D/2-1,z,.24),.10,4)
# Deep projecting copper cornice and repeated brackets.
for z,extra,thick in [(H-.5,.7,.5),(H+.1,1.4,.65),(H+1,1.65,.30)]:metal.box((0,0,z),(W+extra,D+extra,thick),2)
for side,length in [('E',D),('W',D),('N',W),('S',W)]:
    for u in np.arange(-length/2+1,length/2,1.7):metal.rod(pface(side,u,H-2.1,.05),pface(side,u,H+.15,.8),.12,2)
    # Roof glass clerestory, traditional shallow triangular pediment.
    roofbase=H+1.1;peak=H+8.3
    for u in np.arange(-length/2,length/2,1.2):
        v=min(u+1.2,length/2);h1=roofbase+1.2+(peak-roofbase-1.2)*(1-abs(u)/(length/2));h2=roofbase+1.2+(peak-roofbase-1.2)*(1-abs(v)/(length/2))
        metal.face([pface(side,u,roofbase,.5),pface(side,v,roofbase,.5),pface(side,v,h2,.5),pface(side,u,h1,.5)],3)
        metal.rod(pface(side,u,roofbase,.58),pface(side,u,h1,.58),.055,2)
    for z in np.arange(roofbase,peak,1.1):
        half=(length/2)*(1-(z-roofbase-1.2)/(peak-roofbase-1.2));half=min(length/2,max(0,half))
        metal.rod(pface(side,-half,z,.58),pface(side,half,z,.58),.055,2)
    metal.rod(pface(side,-length/2,roofbase+1.2,.6),pface(side,0,peak,.6),.18,2)
    metal.rod(pface(side,0,peak,.6),pface(side,length/2,roofbase+1.2,.6),.18,2)
# Copper roof quadrants with a central glazed winter-garden skylight.
roofz=H+1.8;top=H+8.3
corn=[(-W/2,-D/2,roofz),(W/2,-D/2,roofz),(W/2,D/2,roofz),(-W/2,D/2,roofz)]
inner=[(-W*.28,-D*.32,top),(W*.28,-D*.32,top),(W*.28,D*.32,top),(-W*.28,D*.32,top)]
for i in range(4):
    j=(i+1)%4;mid=((corn[i][0]+corn[j][0])/2,(corn[i][1]+corn[j][1])/2,top)
    metal.face([corn[i],mid,inner[i]],2)
    metal.face([mid,inner[j],inner[i]],2)
    metal.face([mid,corn[j],inner[j]],2)
metal.face(inner,3)
for x in np.arange(-W*.28,W*.28,1.6):metal.rod((x,-D*.32,top+.08),(x,D*.32,top+.08),.055,2)
for y in np.arange(-D*.32,D*.32,1.6):metal.rod((-W*.28,y,top+.08),(W*.28,y,top+.08),.055,2)
def leaf(c,angle,height,width):
    # Curved folded metal leaf; stylized source geometry awaiting sculpt review.
    dx,dy=math.cos(angle),math.sin(angle);px,py=-dy,dx
    for j in range(8):
        ts=[j/8,(j+1)/8];rows=[]
        for t in ts:
            spread=width*math.sin(math.pi*t)**.7*(1+.23*math.sin(t*8*math.pi));out=height*.18*math.sin(t*math.pi*.8);z=c[2]+height*t
            rows.append([(c[0]+dx*out+px*spread,c[1]+dy*out+py*spread,z),(c[0]+dx*(out+.25),c[1]+dy*(out+.25),z+.12),(c[0]+dx*out-px*spread,c[1]+dy*out-py*spread,z)])
        for k in [0,1]:orn.face([rows[0][k],rows[0][k+1],rows[1][k+1],rows[1][k]],2)
def owl(c,size,front):
    orn.ellipsoid((c[0],c[1],c[2]+size*.38),(size*.24,size*.21,size*.42),2,6,10)
    orn.ellipsoid((c[0],c[1],c[2]+size*.86),(size*.25,size*.23,size*.23),2,6,10)
    dx,dy=math.cos(front),math.sin(front);px,py=-dy,dx
    for sign in [-1,1]:
        eye=(c[0]+dx*size*.18+px*sign*size*.10,c[1]+dy*size*.18+py*sign*size*.10,c[2]+size*.91)
        orn.ellipsoid(eye,(size*.07,size*.07,size*.07),5,4,8)
        orn.rod((eye[0]-px*sign*size*.065,eye[1]-py*sign*size*.065,eye[2]+size*.08),(eye[0]+px*sign*size*.1,eye[1]+py*sign*size*.1,eye[2]+size*.13),size*.045,2)
        orn.rod((c[0]+px*sign*size*.17,c[1]+py*sign*size*.17,c[2]+size*1.01),(c[0]+px*sign*size*.25,c[1]+py*sign*size*.25,c[2]+size*1.16),size*.055,2)
        for j in range(6):
            a=(c[0]+px*sign*size*.22,c[1]+py*sign*size*.22,c[2]+size*.62)
            b=(c[0]+px*sign*size*(.52+j*.07),c[1]+py*sign*size*(.52+j*.07),c[2]+size*(.70-j*.095))
            orn.rod(a,b,size*(.075-j*.005),2,6)
    orn.rod((c[0]+dx*size*.2,c[1]+dy*size*.2,c[2]+size*.83),(c[0]+dx*size*.38,c[1]+dy*size*.38,c[2]+size*.7),size*.055,2)
for x in [-W/2,W/2]:
    for y in [-D/2,D/2]:
        sx=1 if x>0 else -1;sy=1 if y>0 else -1
        angle=math.atan2(y,x);c=(x-sx*1.8,y-sy*1.8,H+1)
        owl(c,3.6576,angle)
        for i in range(13):
            inward=math.atan2(-sy,-sx)+(i%5-2)*.22
            leaf((x-sx*(2+(i%4)*.7),y-sy*(2+(i//4)*.7),H+2),inward,5+(i%5)*1.75,1.0+(i%3)*.32)
# State Street great horned owl: source states 20 ft high, 20 ft span.
owl((W/2-1.5,0,H+8.3),6.096,0)
for side,sgn in [('N',1),('S',-1)]:
    for i in range(15):leaf(((i-7)*.7,sgn*D/2,H+8.2),i*1.7,2.8+(i%4)*.6,.6)
details=detail.finish();roof=metal.finish();ornaments=orn.finish()
source=[shell,details,roof,ornaments]
# Editable source retains separate architecture groups and a measured footprint guide.
bpy.ops.object.empty_add(type='PLAIN_AXES',location=(0,0,0));origin=bpy.context.object;origin.name='X_Bean_X | measured origin; east facade +X';origin['creator']='X_Bean_X'
for o in source:o.parent=origin
scene.world=bpy.data.worlds.new('Studio');scene.world.use_nodes=True;scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.45,.52,.59,1);scene.world.node_tree.nodes['Background'].inputs[1].default_value=.7
def point_at(obj,p):obj.rotation_euler=(Vector(p)-obj.location).to_track_quat('-Z','Y').to_euler()
bpy.ops.object.light_add(type='AREA',location=(80,-110,140));key=bpy.context.object;key.name='Studio key';key.data.energy=130000;key.data.shape='DISK';key.data.size=100;point_at(key,(0,0,20))
bpy.ops.object.light_add(type='SUN',location=(0,0,100));sun=bpy.context.object;sun.data.energy=2.1;sun.rotation_euler=(.45,-.4,-.6);sun.data.angle=.15
bpy.ops.object.camera_add(location=(145,-190,130));cam=bpy.context.object;scene.camera=cam;cam.data.type='ORTHO';cam.data.ortho_scale=170;point_at(cam,(0,0,24))
scene.render.engine='CYCLES';scene.cycles.samples=24;scene.cycles.use_denoising=True
scene.render.resolution_x=1600;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
scene.view_settings.view_transform='AgX';scene.view_settings.exposure=.7;scene.render.image_settings.file_format='PNG';scene.render.film_transparent=False
bpy.ops.mesh.primitive_plane_add(size=600,location=(0,0,-.08));ground=bpy.context.object;ground.name='STUDIO ground - excluded from export'
gm=bpy.data.materials.new('Studio ground');gm.diffuse_color=(.16,.20,.23,1);ground.data.materials.append(gm)
# GPU if available, without changing user preferences on disk.
try:
    prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='OPTIX';prefs.get_devices()
    for dev in prefs.devices:dev.use=dev.type=='OPTIX'
    if any(d.type=='OPTIX' for d in prefs.devices):scene.cycles.device='GPU'
except Exception:pass
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source/X_Bean_X_HaroldWashingtonLibrary_v001.blend'))
print('SOURCE_SAVED',flush=True)
# Export separate candidate meshes at three levels of detail.
export=[]
for lod,ratio in [(0,1),(1,.35),(2,.08)]:
    copies=[]
    for src in source:
        o=src.copy();o.data=src.data.copy();o.parent=None;scene.collection.objects.link(o);copies.append(o)
    bpy.ops.object.select_all(action='DESELECT')
    for o in copies:o.select_set(True)
    bpy.context.view_layer.objects.active=copies[0];bpy.ops.object.join();o=bpy.context.object
    # Native importer splits underscores for suffix parsing. Creator stays X_Bean_X;
    # the asset stem deliberately has no underscores before the documented LOD suffix.
    name='HaroldWashingtonLibrary'+(f'_LOD{lod}' if lod else '')
    o.name=o.data.name=name;o['Author']='X_Bean_X';o['creator']='X_Bean_X';o.data['author']='X_Bean_X'
    if lod:
        mod=o.modifiers.new('Distance reduction','DECIMATE');mod.ratio=ratio;bpy.ops.object.modifier_apply(modifier=mod.name)
    tri=o.modifiers.new('Triangulation','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
    path=stage/(name+'.fbx')
    bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'MESH'},global_scale=1,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='FACE',use_tspace=True,add_leaf_bones=False,bake_anim=False,path_mode='AUTO',use_custom_props=True)
    tree,_=parse_fbx.parse(str(path));objects=next(e for e in tree.elems if e.id==b'Objects');vv=[]
    for g in objects.elems:
        if g.id==b'Geometry':
            for q in g.elems:
                if q.id==b'Vertices':vv.append(np.array(q.props[0]).reshape(-1,3)*.01)
    pts=np.concatenate(vv);low=pts.min(axis=0);hi=pts.max(axis=0)
    bm=bmesh.new();bm.from_mesh(o.data);deg=sum(f.calc_area()<1e-9 for f in bm.faces);bm.free()
    uv=o.data.uv_layers.active
    export.append({'file':path.name,'lod':lod,'triangles':len(o.data.polygons),'vertices':len(o.data.vertices),'raw_fbx_native_scale':.01,'bounds_min_m':low.tolist(),'bounds_max_m':hi.tolist(),'size_m':(hi-low).tolist(),'degenerate_faces':deg,'uv_present':uv is not None,'finite_coordinates':bool(np.isfinite(pts).all())})
    for suffix in ['BaseColor','MaskMap','Normal','ControlMask']:shutil.copy2(R/'Textures'/('HWL_'+suffix+'.png'),stage/(name+'_'+suffix+'.png'))
    bpy.data.objects.remove(o,do_unlink=True)
(R/'Validation/mesh_export_report.json').write_text(json.dumps({'creator':'X_Bean_X','status':'FBX candidates; NOT imported or game-ready','meshes':export,'vertical_uncertainty':'Masonry cornice 39.624m provisional from published approximate 130ft description; roof profile reconstructed from photographs. No as-built elevation drawing verified.','ornament_uncertainty':'Five owl motifs and seven crest positions; stylized foliage meshes require sculpted refinement.','texture_note':'Original procedural 2048 atlas; no reference photo pixels reused. Mask R metallic G AO B reserved A smoothness. Native interpretation still requires import validation.'},indent=2))
print('EXPORT_COMPLETE '+json.dumps(export),flush=True)
scene.render.filepath=str(R/'Renders/01_southeast_draft.png');bpy.ops.render.render(write_still=True)
cam.location=(-145,190,120);point_at(cam,(0,0,24));scene.render.filepath=str(R/'Renders/02_northwest_draft.png');bpy.ops.render.render(write_still=True)
cam.location=(180,0,25);cam.data.ortho_scale=130;point_at(cam,(0,0,25));scene.render.filepath=str(R/'Renders/03_state_street_elevation_draft.png');bpy.ops.render.render(write_still=True)
print('BUILD_AND_RENDERS_COMPLETE',flush=True)
