from pathlib import Path
R=Path(__file__).resolve().parents[1]
code=(R/'Scripts/repair_native_faces_v003.py').read_text()
code=code.replace("stage=R/'Import/HaroldWashingtonLibrary'","stage=R/'ImportV003/HaroldWashingtonLibraryV3';stage.mkdir(parents=True,exist_ok=True)")
code=code.replace("exec(compile(code,'export_repaired','exec'))","code=code.replace('HaroldWashingtonLibrary','HaroldWashingtonLibraryV3');exec(compile(code,'export_repaired','exec'))")
code=code.replace("exec(compile(stable,'stable_lod_repaired','exec'))","stable=stable.replace('Import/HaroldWashingtonLibrary/HaroldWashingtonLibrary_LOD2.fbx','ImportV003/HaroldWashingtonLibraryV3/HaroldWashingtonLibraryV3_LOD2.fbx').replace(\"'HaroldWashingtonLibrary_LOD2'\",\"'HaroldWashingtonLibraryV3_LOD2'\");exec(compile(stable,'stable_lod_repaired','exec'))")
exec(compile(code,'versioned_export','exec'))
import shutil
for suffix in ['BaseColor','MaskMap','Normal','ControlMask']:
 shutil.copy2(R/'Textures'/('HWL_'+suffix+'.png'),R/'ImportV003/HaroldWashingtonLibraryV3'/('HaroldWashingtonLibraryV3_LOD2_'+suffix+'.png'))
