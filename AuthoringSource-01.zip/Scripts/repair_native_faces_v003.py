"""Repair verified inward-facing planar facade panels. Creator X_Bean_X."""
import bpy,bmesh,json,shutil,numpy as np
from pathlib import Path
from io_scene_fbx import parse_fbx
R=Path(__file__).resolve().parents[1];stage=R/'Import/HaroldWashingtonLibrary'
def repair():
 rows=[]
 for o in bpy.data.objects:
  if o.type!='MESH' or not o.name.startswith(('02','03')):continue
  bm=bmesh.new();bm.from_mesh(o.data);fix=[]
  for f in bm.faces:
   c=f.calc_center_median();n=f.normal;pts=np.array([v.co for v in f.verts]);ext=np.ptp(pts,axis=0)
   planar_wall=(ext[0]<.001 and abs(c.x)>31) or (ext[1]<.001 and abs(c.y)>54)
   if planar_wall and abs(n.z)<.05 and c.x*n.x+c.y*n.y<0:fix.append(f)
  bmesh.ops.reverse_faces(bm,faces=fix);bm.to_mesh(o.data);bm.free();o.data.update();rows.append({'object':o.name,'faces_reversed':len(fix)})
 return rows
bpy.ops.wm.open_mainfile(filepath=str(R/'Source/X_Bean_X_HaroldWashingtonLibrary_v002.blend'))
repairs=repair();scene=bpy.context.scene
scene['status']='Native facade backface correction; validation in progress'
bpy.ops.wm.save_as_mainfile(filepath=str(R/'Source/X_Bean_X_HaroldWashingtonLibrary_v003.blend'))
source=[o for o in bpy.data.objects if o.type=='MESH' and o.name[:2] in ['01','02','03','04']]
code=(R/'Scripts/build_library.py').read_text();code=code[code.index('export=[]'):code.index("(R/'Validation/mesh_export_report.json')")]
code=code.replace('[(0,1),(1,.35),(2,.08)]','[(0,1),(1,.35)]')
exec(compile(code,'export_repaired','exec'))
report=json.loads((R/'Validation/mesh_export_report.json').read_text());report['meshes'][:2]=export;report['source']='Source/X_Bean_X_HaroldWashingtonLibrary_v003.blend'
(R/'Validation/mesh_export_report.json').write_text(json.dumps(report,indent=2))
bpy.ops.wm.open_mainfile(filepath=str(R/'Source/X_Bean_X_HaroldWashingtonLibrary_v001.blend'))
lodrepairs=repair()
stable=(R/'Scripts/build_stable_lod2.py').read_text();stable=stable[stable.index('objs='):]
exec(compile(stable,'stable_lod_repaired','exec'))
(R/'Validation/facade-repair-v003.json').write_text(json.dumps({'main':repairs,'distant_source':lodrepairs,'author':'X_Bean_X'},indent=2))
print('FACADE_REPAIR_COMPLETE',repairs,lodrepairs)
