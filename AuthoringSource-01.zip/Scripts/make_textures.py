"""Original procedural PBR atlas. No reference-photo pixels used. Creator X_Bean_X."""
from pathlib import Path
import numpy as np
from PIL import Image
R=Path(__file__).resolve().parents[1];T=R/'Textures';T.mkdir(exist_ok=True)
rng=np.random.default_rng(407);s=2048;t=512
base=np.zeros((s,s,4),dtype=np.uint8);base[:,:,3]=255
mask=np.zeros_like(base);mask[:,:,1]=0 # CS2 clear coat, not ambient occlusion
normal=np.zeros_like(base);normal[:]=[128,128,255,255]
palette=[(145,71,52),(164,125,99),(68,126,115),(69,103,116),(35,66,61),(25,45,50),(169,134,68),(91,93,89)]
yy,xx=np.indices((t,t))
for i,color in enumerate(palette):
    x=(i%4)*t;y=(i//4)*t
    noise=rng.normal(0,2.3,(t,t))
    arr=np.clip(np.array(color)+noise[:,:,None],0,255).astype(np.uint8)
    if i in [0,1]:
        bh,bw=(16,38) if i==0 else (128,256)
        joints=(yy%bh<2)|((xx+(yy//bh%2)*(bw//2))%bw<2)
        arr[joints]=np.array(color)*.73
        normal[y:y+t,x:x+t][joints]=[126,136,250,255]
    if i==2:
        patina=(np.sin(xx/43)+np.cos(yy/71)+rng.normal(0,.3,(t,t)))*6
        arr=np.clip(arr.astype(float)+patina[:,:,None],0,255).astype(np.uint8)
    if i in [3,5]:
        arr=np.clip(arr.astype(float)+(np.sin(xx/98+yy/83)*7)[:,:,None],0,255).astype(np.uint8)
    base[y:y+t,x:x+t,:3]=arr
    mask[y:y+t,x:x+t,0]=[0,0,170,120,180,90,210,0][i]
    mask[y:y+t,x:x+t,3]=[45,55,135,220,110,190,155,40][i]
Image.fromarray(base).save(T/'HWL_BaseColor.png')
Image.fromarray(mask).save(T/'HWL_MaskMap.png')
Image.fromarray(normal).save(T/'HWL_Normal.png')
Image.fromarray(np.zeros_like(base)).save(T/'HWL_ControlMask.png')
print('Generated four 2048x2048 original atlas maps, creator X_Bean_X')
