"""X_Bean_X: retain coarse v001 architecture for the distant LOD.
Aggressive decimation of v002 fine scroll rods produced an invalid vertical
extent. Use the simpler retained source; verify bounds before exporting.
"""
import bpy,bmesh,json,numpy as np
from pathlib import Path
R=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(R/'Source/X_Bean_X_HaroldWashingtonLibrary_v001.blend'))
objs=[o for o in bpy.data.objects if o.type=='MESH' and o.name[:2] in ['01','02','03','04']]
bpy.ops.object.select_all(action='DESELECT')
for o in objs:o.select_set(True);o.parent=None
bpy.context.view_layer.objects.active=objs[0];bpy.ops.object.join();o=bpy.context.object
o.name=o.data.name='HaroldWashingtonLibrary_LOD2';o['Author']='X_Bean_X'
mod=o.modifiers.new('Coarse architecture','DECIMATE');mod.ratio=.08;bpy.ops.object.modifier_apply(modifier=mod.name)
tri=o.modifiers.new('Triangulate','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=tri.name)
pts=np.array([v.co for v in o.data.vertices]);assert pts[:,2].min()>=-.01 and pts[:,2].max()<56
path=R/'Import/HaroldWashingtonLibrary/HaroldWashingtonLibrary_LOD2.fbx'
bpy.ops.export_scene.fbx(filepath=str(path),use_selection=True,object_types={'MESH'},global_scale=1,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',axis_forward='-Z',axis_up='Y',bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type='FACE',use_tspace=True,add_leaf_bones=False,bake_anim=False,path_mode='AUTO',use_custom_props=True)
report=json.loads((R/'Validation/mesh_export_report.json').read_text())
entry=report['meshes'][2];p=np.column_stack([pts[:,0],pts[:,2],-pts[:,1]])
entry.update(triangles=len(o.data.polygons),vertices=len(o.data.vertices),bounds_min_m=p.min(axis=0).tolist(),bounds_max_m=p.max(axis=0).tolist(),size_m=np.ptp(p,axis=0).tolist(),source='Retained v001 simplified architecture; fine v002 scrolls intentionally omitted at distance')
(R/'Validation/mesh_export_report.json').write_text(json.dumps(report,indent=2));print(json.dumps(entry))
