using System;using System.Linq;using System.Collections.Generic;using ChicagoBuildBridge;using Colossal.IO.AssetDatabase;using Game.Prefabs;using Newtonsoft.Json.Linq;using Unity.Collections;using Unity.Entities;using Unity.Mathematics;
namespace ChicagoBuildExtensions{public static class Entry{public static object Run(BridgeSystem b,JObject c){
var ps=b.World.GetExistingSystemManaged<PrefabSystem>();RenderPrefab mesh=null;using(var q=b.EntityManager.CreateEntityQuery(ComponentType.ReadOnly<PrefabData>()))using(var es=q.ToEntityArray(Allocator.Temp))foreach(var e in es){var name=ps.GetPrefabName(e);if(name=="HaroldWashingtonLibraryV4")throw new Exception("Version 3 building already exists");if(name=="HaroldWashingtonLibraryV3 Mesh")mesh=ps.GetPrefab<RenderPrefab>(e);}
if(mesh==null)throw new Exception("Expected corrected native mesh missing");
if(!ps.TryGetPrefab(new PrefabID("BuildingPrefab","CN_ModernLibrary"),out var source))throw new Exception("Template missing");
var p=PrefabBase.Create<BuildingPrefab>("HaroldWashingtonLibraryV4");var copy=new HashSet<string>{"ServiceConsumption","ResearchFacility","CityEffects","ServiceObject","PlaceableObject","Workplace","CityServiceBuilding","UIObject","Pollution","Attraction","LeisureProvider","LocalEffects"};foreach(var co in source.components)if(copy.Contains(co.GetType().Name))p.AddComponentFrom(co);
p.m_Meshes=new[]{new ObjectMeshInfo{m_Mesh=mesh,m_Position=float3.zero,m_Rotation=quaternion.RotateY(math.radians(-90f))}};p.m_LotWidth=14;p.m_LotDepth=8;p.m_AccessType=((BuildingPrefab)source).m_AccessType;
var u=p.AddOrGetComponent<Unlockable>();u.m_RequireAll=new PrefabBase[0];u.m_RequireAny=new PrefabBase[0];u.m_IgnoreDependencies=true;
p.AddOrGetComponent<ObsoleteIdentifiers>().m_PrefabIdentifiers=new[]{new PrefabIdentifierInfo{m_Type="BuildingPrefab",m_Name=p.name}};
var a=AssetDatabase.user.AddAsset(AssetDataPath.Create("X_Bean_X/HaroldWashingtonLibraryV4",p.name),p);a.Save();bool added=ps.AddPrefab(p);ps.Update();return new{status="created",added,author="X_Bean_X",asset=a.path,mesh=mesh.name};
}}}

