"""Detailed exterior geometry based on photographs and the measured Chicago GPT lot."""
from dataclasses import dataclass
import math
import random

from mathutils import Vector

from library_mesh import MeshPart, clip, clipped_rect, rect
from library_released_body import load_released_body
from library_roof import ReferenceRoof


WIDTH = 63.42554414
LENGTH = 109.24487609
CORNICE = 39.624
ROOF_JOIN = CORNICE+1.15
UP = Vector((0, 0, 1))
XYZ = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]


@dataclass
class Elevation:
    name: str
    short: str
    width: float
    distance: float
    tangent: tuple
    normal: tuple

    def point(self, u, z, offset=0):
        return Vector(self.tangent)*u + Vector(self.normal)*(self.distance+offset) + UP*z

    @property
    def axes(self):
        return (self.tangent, -Vector(self.normal), UP)

    def box(self, part, u, z, offset, width, height, depth, color):
        part.box(self.point(u, z, offset), self.axes, (width, depth, height), color)

    def vertical(self, part, u, z0, z1, offset, width, depth, color):
        self.box(part, u, (z0+z1)/2, offset, width, z1-z0, depth, color)

    def horizontal(self, part, u0, u1, z, offset, height, depth, color):
        self.box(part, (u0+u1)/2, z, offset, u1-u0, height, depth, color)


EAST = Elevation("State Street", "E", LENGTH, WIDTH/2, (0,1,0), (1,0,0))
SOUTH = Elevation("Ida B. Wells Drive", "S", WIDTH, LENGTH/2, (1,0,0), (0,-1,0))
NORTH = Elevation("Van Buren Street", "N", WIDTH, LENGTH/2, (-1,0,0), (0,1,0))
WEST = Elevation("Plymouth Court", "W", LENGTH, WIDTH/2, (0,-1,0), (-1,0,0))
BRICK_SIDES = (EAST, SOUTH, NORTH)
SIDES = (*BRICK_SIDES, WEST)


@dataclass(frozen=True)
class Opening:
    u: float
    bottom: float
    spring: float
    radius: float
    rise: float

    def outline(self, shrink=0, samples=22):
        radius = self.radius - shrink
        rise = self.rise - shrink if self.rise else 0
        if not self.rise:
            return [(self.u-radius,self.bottom), (self.u-radius,self.spring-shrink),
                    (self.u+radius,self.spring-shrink), (self.u+radius,self.bottom)]
        return [(self.u-radius,self.bottom)] + [
            (self.u-radius*math.cos(math.pi*i/samples), self.spring+rise*math.sin(math.pi*i/samples))
            for i in range(samples+1)] + [(self.u+radius,self.bottom)]

    def field(self, shrink=0):
        return list(reversed(self.outline(shrink)))


@dataclass(frozen=True)
class Pane:
    side: str
    section: str
    cluster: tuple
    poly: tuple
    world: tuple
    appearance: str


class Exterior:
    def __init__(self):
        self.shell = MeshPart("01 Brick and granite shell")
        self.glass = MeshPart("02 Window glass and recessed reading rooms")
        self.roof = MeshPart("03 Winter Garden and metal roof")
        self.crest = MeshPart("04 Sculpted owl and foliage silhouettes")
        self.trim = MeshPart("05 Architectural trim and entrance details", 1)
        self.sculpt = MeshPart("06 Carved garlands and medallions", 1)
        self.fine = MeshPart("07 Lanterns, grilles and fine roof cresting", 2)
        self.parts = [self.shell, self.glass, self.roof, self.crest, self.trim, self.sculpt, self.fine]
        self.panes = []
        self.lanterns = []

    @staticmethod
    def panel(part, side, poly, color, depth=0):
        part.face([side.point(u,z,depth) for u,z in poly], color)

    @staticmethod
    def tiled(part, side, poly, color, depth=0, tile=(3.65, 3.65)):
        du, dz = tile
        for col in range(math.floor(min(u for u,z in poly)/du), math.ceil(max(u for u,z in poly)/du)):
            for row in range(math.floor(min(z for u,z in poly)/dz), math.ceil(max(z for u,z in poly)/dz)):
                u0, z0 = col*du, row*dz
                field = clipped_rect(poly, u0,z0,u0+du,z0+dz)
                if field:
                    part.face([side.point(u,z,depth) for u,z in field], color,
                              [((u-u0)/du,(z-z0)/dz) for u,z in field])

    def wall(self, side, bottom, top, holes, material, banding=False, bounds=None):
        left, right = bounds or (-side.width/2, side.width/2)
        def section(poly):
            self.tiled(self.shell, side, poly, material)
            if banding:
                for level in (14.45,19.64,24.84,30.0,35.20):
                    band = clip(clip(poly, 1, level-.19, True), 1, level+.19, False)
                    if len(band) >= 3:
                        self.tiled(self.shell, side, band, "band", .007)
        cursor = left
        for opening in sorted(holes, key=lambda item: item.u):
            edge_l, edge_r = opening.u-opening.radius, opening.u+opening.radius
            assert cursor <= edge_l and edge_r <= right, (side.name, opening)
            if edge_l > cursor:
                section(rect(cursor,bottom,edge_l,top))
            if opening.bottom > bottom:
                section(rect(edge_l,bottom,edge_r,opening.bottom))
            for (u1,z1),(u2,z2) in zip(opening.outline()[1:-2], opening.outline()[2:-1]):
                section([(u1,min(z1,top)),(u2,min(z2,top)),(u2,top),(u1,top)])
            cursor = edge_r
        if cursor < right:
            section(rect(cursor,bottom,right,top))

    def stepped_arch(self, side, hole, thicknesses, depths, color):
        for i,(outer,inner) in enumerate(zip(thicknesses, thicknesses[1:])):
            rim, next_rim = hole.outline(outer), hole.outline(inner)
            for a,b,c,d in zip(rim, rim[1:], next_rim, next_rim[1:]):
                self.shell.face([side.point(*a, depths[i]), side.point(*c, depths[i]),
                                 side.point(*d, depths[i]), side.point(*b, depths[i])], color)
                self.shell.face([side.point(*c, depths[i]), side.point(*c, depths[i+1]),
                                 side.point(*d, depths[i+1]), side.point(*d, depths[i])], color)

    def pane(self, side, section, key, poly, depth, tint="glass", solid=True):
        if solid:
            self.panel(self.glass, side, poly, tint, depth)
        # Overlay sits a centimetre in front of the glass, behind the projecting mullions.
        world = tuple(tuple(side.point(u,z,depth+.010)) for u,z in poly)
        self.panes.append(Pane(side.short, section, key, tuple(poly), world, tint))

    def glazing(self, side, field, columns, rows, depth, section, bay, gap, rng):
        self.panel(self.glass, side, field, "dark", depth-.028)
        room_columns = [int(c // (2 if bay % 3 else 3)) for c in range(len(columns)-1)]
        for c,(u0,u1) in enumerate(zip(columns, columns[1:])):
            for r,(z0,z1) in enumerate(zip(rows, rows[1:])):
                hg = gap*1.5 if r % 2 == 0 else gap
                cell = clipped_rect(field,u0+gap,z0+hg,u1-gap,z1-hg)
                if not cell:
                    continue
                area = abs(sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(cell,cell[1:]+cell[:1]))) / 2
                if area < .018:
                    continue
                zone = (bay, room_columns[c], (r+(c//7 if section=="curtain" else 0))//2)
                if section == "curtain" and rng.random() < .12:
                    zone = (bay, c, r, "individual")
                self.pane(side, section, zone, cell, depth,
                          "glass-blue" if rng.random()<.18 else "glass")
        for u in columns[1:-1]:
            cut = clipped_rect(field,u-gap,rows[0]-.01,u+gap,rows[-1]+.01)
            if len(cut) >= 3:
                self.panel(self.glass, side, cut, "dark", depth+.018)
        for r,z in enumerate(rows[1:-1], start=1):
            hg = gap*1.4 if r % 2 == 0 else gap*.88
            cut = clipped_rect(field,columns[0]-.01,z-hg,columns[-1]+.01,z+hg)
            if len(cut) >= 3:
                self.panel(self.glass, side, cut, "green" if section=="arch" else "dark", depth+.027)

    def deep_windows(self, side, centers):
        rng = random.Random(2165+ord(side.short))
        arches = [Opening(u,9.76,31.72,4.40 if side==EAST else 4.28,4.55) for u in centers]
        self.wall(side,9.61,37.35,arches,"brick",banding=True)
        for i,hole in enumerate(arches):
            widths = (0,.29,.57,.86,1.15,1.39)
            depths = (0,-.19,-.42,-.64,-.87,-1.12)
            self.stepped_arch(side,hole,widths,depths,"reveal")
            inner=hole.radius-widths[-1]
            columns=[hole.u+inner*x for x in (-1,-.35,.35,1)]
            rows=[9.76,11.85,14.32,16.22,19.55,21.62,24.75,26.73,29.96,31.75,34.88]
            self.glazing(side,hole.field(widths[-1]),columns,rows,-1.136,"arch",i,.042,rng)
            side.horizontal(self.shell,hole.u-hole.radius,hole.u+hole.radius,9.72,-.35,.25,.89,"granite")
        edges = [-side.width/2+3.35] + [(a+b)/2 for a,b in zip(centers,centers[1:])] + [side.width/2-3.35]
        for index, u in enumerate(edges):
            width = 2.65 if 0 < index < len(edges)-1 else 1.65
            self.garland(side,u,width)

    def medallion(self, side, u, z, radius):
        side_basis = side.axes
        self.sculpt.ellipsoid(side.point(u,z,.145),side_basis,(radius,.170,radius),"terracotta",14,6)
        self.sculpt.ellipsoid(side.point(u,z,.261),side_basis,(radius*.64,.080,radius*.64),"band",12,5)
        for i in range(6):
            a=math.tau*i/6
            self.fine.ellipsoid(side.point(u+math.cos(a)*radius*.41,z+math.sin(a)*radius*.41,.333),
                               side_basis,(radius*.25,.049,radius*.21),"terracotta",7,4)

    def garland(self, side, u, width):
        height = 34.66
        for sign in (-1,1):
            x = u+sign*width/2
            self.medallion(side,x,height,.34)
            self.medallion(side,x,10.16,.20)
            for lo,hi in ((10.25,14),(14.77,19.2),(20,24.45),(25.35,29.66),(30.54,34.43)):
                side.vertical(self.sculpt,x,lo,hi,.073,.17,.146,"terracotta")
                for i in range(math.ceil((hi-lo)/.32)):
                    z=lo+.11+i*.30
                    if z<hi:
                        self.fine.ellipsoid(side.point(x+(-1)**i*.065,z,.153),side.axes,
                                            (.10,.067,.18),"band",6,4)
            for row,z in enumerate((14.38,19.60,24.90,30.10)):
                self.pane(side,"slit",(round(x,2),row),rect(x-.112,z-.31,x+.112,z+.31),.015)
        for i in range(13):
            t=i/12
            z=height-.5*math.sin(math.pi*t)
            self.sculpt.ellipsoid(side.point(u+width*(t-.5),z,.14),side.axes,
                                  (.19,.15,.145),"terracotta",8,5)
        self.sculpt.ellipsoid(side.point(u,height-.58,.185),side.axes,(.18,.13,.27),"terracotta",10,5)

    def base(self, side):
        plans = {
            "E": [(-34.0,1.55),(-16.9,2.12),(0,2.74),(16.9,2.12),(34,1.55)],
            "S": [(-20.3,1.58),(0,2.50),(20.3,1.58)],
            "N": [(-19.5,1.66),(0,2.48),(19.5,1.66)],
        }
        doors = [Opening(u,.04,2.32 if r>2 else 2.16,r,r*.69) for u,r in plans[side.short]]
        displays = []
        for (a,_),(b,_) in zip(plans[side.short],plans[side.short][1:]):
            for sign in (-1,1):
                displays.append(Opening((a+b)/2+sign*1.63,.65,2.58,1.17,0))
        vents = []
        for left,right in zip(doors,doors[1:]):
            middle=(left.u+right.u)/2
            for j in (-3,-1,1,3):
                vents.append(Opening(middle+j*.95,6.15,7.43,.46,.50))
        for u in (-side.width/2+4.0,side.width/2-4.0):
            for offset in (-.78,.78):
                vents.append(Opening(u+offset,6.15,7.43,.43,.45))
        self.wall(side,0,3.05,[*doors,*displays],"rusticated")
        capped = [hole for hole in doors if hole.spring+hole.rise > 3.05]
        self.wall_segment_above_door(side,3.05,9.61,capped,vents)
        for i,hole in enumerate(doors):
            self.stepped_arch(side,hole,(0,.24,.47),(0,-.20,-.59),"granite")
            r=hole.radius-.47
            field=hole.field(.47)
            self.panel(self.glass,side,field,"dark",-.867)
            width=r*2
            rows=[(hole.bottom+.10,2.45),(2.55,hole.spring+hole.rise-.42)]
            for row,(z0,z1) in enumerate(rows):
                for j in range(3):
                    l=hole.u-r+j*width/3+.062
                    rr=hole.u-r+(j+1)*width/3-.062
                    q=clipped_rect(field,l,z0,rr,z1)
                    if q:
                        self.pane(side,"entry",(i,row),q,-.849)
            side.horizontal(self.trim,hole.u-r,hole.u+r,2.50,-.827,.09,.13,"brass")
            for uu in (-r,-r/3,r/3,r,0):
                side.vertical(self.trim,hole.u+uu,.1,2.48,-.822,.068,.12,"brass")
            for uu in (-.17,.17):
                side.vertical(self.fine,hole.u+uu,.97,1.47,-.735,.039,.07,"brass")
            side.horizontal(self.shell,hole.u-r-.18,hole.u+r+.18,.045,-.17,.09,.60,"granite")
        for i,hole in enumerate(displays):
            self.stepped_arch(side,hole,(0,.14),(0,-.22),"granite")
            self.pane(side,"display",(i,),hole.field(.14),-.239)
            side.horizontal(self.trim,hole.u-hole.radius,hole.u+hole.radius,.65,-.02,.12,.26,"granite")
        for i,hole in enumerate(vents):
            self.stepped_arch(side,hole,(0,.12),(0,-.26),"granite")
            self.pane(side,"base-arch",(i,),hole.field(.12),-.281)
            for j in (-2,-1,0,1,2):
                side.vertical(self.fine,hole.u+j*.112,hole.bottom,hole.spring+.04,-.155,.034,.043,"green")
        for z,height,reach in ((.33,.31,.05),(3.08,.20,.11),(3.38,.31,.10),(9.54,.29,.20)):
            cursor = -side.width/2
            for door in doors:
                if z-height/2 < door.spring+door.rise:
                    side.horizontal(self.trim,cursor,door.u-door.radius-.04,z,reach/2,height,reach,"granite")
                    cursor = door.u+door.radius+.04
            side.horizontal(self.trim,cursor,side.width/2,z,reach/2,height,reach,"granite")
        for i in range(math.ceil(side.width/.56)):
            u=-side.width/2+.28+i*.56
            if u > side.width/2-.24 or any(abs(u-h.u)<h.radius+.20 for h in capped):
                continue
            self.fine.ellipsoid(side.point(u,3.40,.115),side.axes,(.235,.075,.143),"band",8,4)
        for i,hole in enumerate(doors):
            if i % 2 == 0 or hole.radius > 2.3:
                for sgn in (-1,1):
                    self.fixture(side,hole.u+sgn*(hole.radius+.86),3.04,(i==len(doors)//2))

    def wall_segment_above_door(self, side, bottom, top, caps, vents):
        # Cut the top of each entrance out of the lower part of the dressed granite.
        cursor=-side.width/2
        for hole in caps:
            left, right = hole.u-hole.radius, hole.u+hole.radius
            self.tiled(self.shell,side,rect(cursor,bottom,left,6.00),"granite")
            for (u1,z1),(u2,z2) in zip(hole.outline()[1:-2],hole.outline()[2:-1]):
                self.tiled(self.shell,side,[(u1,max(z1,bottom)),(u2,max(z2,bottom)),
                                           (u2,6.0),(u1,6.0)],"granite")
            cursor=right
        self.tiled(self.shell,side,rect(cursor,bottom,side.width/2,6.0),"granite")
        self.wall(side,6,top,vents,"granite")

    def fixture(self, side, u, z, main):
        side.box(self.trim,u,z,.089,.26,.54,.17,"green")
        self.trim.pipe(side.point(u,z+.14,.075),side.point(u,z+.24,.32),.055,"dark",8)
        side.box(self.trim,u,z-.04,.342,.25,.41,.25,"brass")
        side.box(self.fine,u,z-.04,.374,.189,.300,.247,"book")
        side.box(self.trim,u,z+.19,.348,.31,.105,.31,"dark")
        side.box(self.trim,u,z-.27,.348,.29,.077,.30,"dark")
        self.lanterns.append((side.short,u,z,main))

    def curtain_wall(self):
        side=WEST
        w=side.width/2
        plinth=7.18
        self.wall(side,0,plinth,[Opening(-36,.05,3.88,2.55,0),
                                  Opening(-18,.05,4.0,2.22,0),
                                  Opening(32,.05,3.94,2.0,0)],"green")
        for u,width in ((-36,4.97),(-18,4.32),(32,3.87)):
            side.box(self.trim,u,1.99,-.36,width,3.88,.18,"dark")
            for k in range(10):
                side.horizontal(self.fine,u-width/2,u+width/2,.27+k*.365,-.24,.058,.11,"green")
        for u,width in ((-28,5.6),(-10.1,4.5),(18.5,4.8),(43,5.2)):
            side.box(self.trim,u,2.32,.065,width,3.10,.13,"dark")
            for j in range(11):
                side.horizontal(self.fine,u-width/2,u+width/2,.97+j*.253,.144,.048,.09,"green")
        for z in (4.44,7.03):
            side.horizontal(self.trim,-w,w,z,.08,.18,.16,"green")
        left,right=-w+1.35,w-1.35
        self.wall(side,plinth,CORNICE,[],"brick",bounds=(-w,left))
        self.wall(side,plinth,CORNICE,[],"brick",bounds=(right,w))
        n=68
        columns=[left+(right-left)*i/n for i in range(n+1)]
        rows=[plinth+(CORNICE+1.69-plinth)*i/17 for i in range(18)]
        from library_rooms import build_curtain_rooms
        self.rooms, self.clear_glass, room_parts = build_curtain_rooms(self, side, columns, rows)
        self.parts.extend(room_parts)
        for j,x in enumerate(columns):
            side.vertical(self.glass,x,plinth,CORNICE+1.70,.026,
                          .105 if j%4 else .161,.15,"dark")
        for j,z in enumerate(rows):
            side.horizontal(self.glass,left,right,z,.029,.173 if j%2==0 else .075,.13,"green")

    def build(self, released_project):
        load_released_body(self,released_project,SIDES,WEST,ROOF_JOIN)
        # Both long elevations carry five copies of the released entry lantern.
        for side in SIDES:
            centers = (-35,-17.5,0,17.5,35) if side in (EAST,WEST) else (-20,0,20)
            for center in centers:
                self.lanterns.append((side.short,center,5.60,center==0))
        self.build_roof()
        return self

    @staticmethod
    def gable_height(side,u):
        slope = 5.22 if side in (EAST,WEST) else 6.85
        return 41.43 + slope * (1-abs(u)/(side.width/2))

    def build_roof(self):
        for side in SIDES:
            self.glazed_gable(side)
        roof=ReferenceRoof(WIDTH,LENGTH)
        self.parts.append(roof.build())
        self.skylight_faces=roof.skylights
        for sx in (-1,1):
            for sy in (-1,1):
                self.corner_crest(sx,sy)
        for side in (NORTH,SOUTH):
            self.fan_crest(side,0,self.gable_height(side,0)-.92,False)
        self.fan_crest(EAST,0,self.gable_height(EAST,0)-1.23,True)

    def cornice(self,side):
        w=side.width/2
        self.tiled(self.shell,side,rect(-w,37.35,w,CORNICE),"brick")
        for z,height,depth,material in (
            (39.08,.64,.39,"green"),(39.58,.35,.47,"dark"),(39.91,.22,.51,"green"),(40.14,.18,.45,"crest")
        ):
            side.horizontal(self.roof,-w,w,z,depth/2,height,depth,material)
        count=round(side.width/1.63)
        for i in range(count):
            u=-w+side.width*(i+.5)/count
            self.cornice_bracket(side,u)
            if i < count-1:
                center=u+side.width/count/2
                pane=rect(center-.29,37.67,center+.29,38.46)
                side.box(self.trim,center,38.06,.011,.78,.99,.09,"terracotta")
                self.pane(side,"cornice",(i//2,),pane,.063)
                for j in (-1,0,1):
                    side.horizontal(self.fine,center-.29,center+.29,38.05+j*.17,.088,.028,.03,"dark")

    def cornice_bracket(self,side,u):
        profile = [(.02,37.47),(.105,37.53),(.173,37.99),(.244,38.46),(.345,38.80),
                   (.50,39.05),(.51,39.44),(.03,39.44)]
        pa = [side.point(u-.123,z,reach) for reach,z in profile]
        pb = [side.point(u+.123,z,reach) for reach,z in profile]
        self.roof.face(pa,"green")
        self.roof.face(pb[::-1],"green")
        for a,b,c,d in zip(pa,pa[1:]+pa[:1],pb,pb[1:]+pb[:1]):
            self.roof.face([a,c,d,b],"green")

    def glazed_gable(self,side):
        w=side.width/2
        top=self.gable_height(side,0)
        n=round(side.width/1.45)
        us=[-w+side.width*i/n for i in range(n+1)]
        rows=[ROOF_JOIN,41.81,42.94,44.08,45.22,46.36,47.50,48.62]
        field=[(-w,ROOF_JOIN),(w,ROOF_JOIN),(w,self.gable_height(side,w)),(0,top),(-w,self.gable_height(side,-w))]
        self.glazing(side,field,us,rows,-.055,"gable",0,.048,random.Random(637+ord(side.short)))
        for u in us:
            side.vertical(self.roof,u,ROOF_JOIN,self.gable_height(side,u),.034,.11,.13,"green")
        for a,b in zip(us,us[1:]):
            t=(a+b)/2
            last = self.gable_height(side,t)
            self.roof.pipe(side.point(a,self.gable_height(side,a),.10),
                           side.point(b,self.gable_height(side,b),.10),.117,"green",7)
            self.fine.ellipsoid(side.point(t,last+.18,.153),side.axes,(.27,.097,.29),"crest",8,5)
            self.fine.pipe(side.point(t,last+.21,.122),side.point(t,last+.68,.160),.038,"crest",5)
            self.fine.ellipsoid(side.point(t,last+.65,.160),side.axes,(.063,.055,.124),"crest",7,4)
        for z in (40.86,41.20):
            side.horizontal(self.trim,-w,w,z,.265,.085,.11,"green")
        step=side.width/n
        for i in range(n):
            u=-w+step*(i+.5)
            side.vertical(self.fine,u-step*.49,40.83,41.26,.265,.074,.084,"green")
            for sign in (-1,1):
                self.fine.pipe(side.point(u-sign*step*.39,40.88,.265),
                               side.point(u+sign*step*.39,41.19,.265),.035,"crest",5)
            self.fine.ellipsoid(side.point(u,41.03,.27),side.axes,(.14,.059,.12),"green",8,5)

    def roof_skin(self):
        inset=7.1
        for side in SIDES:
            half = side.width/2
            def edge(u):
                return 41.26 if side==WEST else self.gable_height(side,u)-.03
            n=math.ceil(side.width/1.47)
            pts=[-half+side.width*i/n for i in range(n+1)]
            if n % 2:
                pts.append(0)
                pts.sort()
            def eave(u):
                return side.point(u,edge(u),-.124)
            def deck(u):
                return side.point(u*(half-inset)/half,45.66,-inset)
            for a,b in zip(pts,pts[1:]):
                self.roof.face([eave(a),eave(b),deck(b),deck(a)],"roof")
                self.trim.pipe(eave(a)+UP*.046,deck(a)+UP*.046,.032,"green",5)
            # The corners meet at diagonals so there are no holes behind the glazed gables.
            u = half
            out = eave(u)
            if side != WEST:
                self.roof.pipe(out,deck(u),.092,"green",6)
        for sx in (-1,1):
            for sy in (-1,1):
                x,y=sx*(WIDTH/2-.12),sy*(LENGTH/2-.12)
                self.roof.box((x,y,42.05),XYZ,(.47,.47,3.0),"crest")

    def vault(self,x0,half,y0,y1,base,rise,skylight):
        edges=[y0+(y1-y0)*i/30 for i in range(31)]
        if skylight:
            edges=sorted(set((*edges,*skylight)))
        def point(i,y):
            a=math.pi*i/24
            return Vector((x0-half*math.cos(a),y,base+rise*math.sin(a)))
        for direction in (-1,1):
            x=x0+direction*half
            wall=[(x,y0,45.19),(x,y1,45.19),(x,y1,base),(x,y0,base)]
            self.roof.face(wall if direction==1 else wall[::-1],"green")
        for i in range(24):
            a0,a1=point(i,y0),point(i+1,y0)
            for y_a,y_b in zip(edges,edges[1:]):
                glazed=skylight and y_a>=skylight[0] and y_b<=skylight[1] and 2<=i<=21
                self.roof.face([point(i,y_a),point(i+1,y_a),point(i+1,y_b),point(i,y_b)],
                               "glass-blue" if glazed else "roof")
            for y in (y0,y1):
                a,b=point(i,y),point(i+1,y)
                pts=[a,b,(b.x,b.y,45.19),(a.x,a.y,45.19)]
                self.roof.face(pts if y==y0 else pts[::-1],"green")
                self.trim.pipe(a+UP*.04,b+UP*.04,.112,"crest",7)
            if i % 2==0:
                self.trim.pipe(a0+UP*.041,point(i,y1)+UP*.041,.037,"green",5)
            if skylight:
                for y in (*skylight,*[t for t in edges if skylight[0]<t<skylight[1]]):
                    self.trim.pipe(point(i,y)+UP*.034,point(i+1,y)+UP*.034,.046,"dark",5)

    @staticmethod
    def leaf(part, root, tip, width, normal, color="crest", lobed=True):
        root,tip,normal=Vector(root),Vector(tip),Vector(normal)
        n=(tip-root).normalized()
        across=n.cross(normal).normalized()
        if across.length < .1:
            across=n.orthogonal().normalized()
        outward=across.cross(n).normalized()
        length=(tip-root).length
        def vertex(i,j):
            t=i/12
            s=j*.5-1
            wr=math.sin(math.pi*t)**.67 * (.94+.075*math.cos(t*6*math.pi))
            if lobed:
                wr*=1+.23*math.sin(11*math.pi*t)
            ridge=math.sin(math.pi*t)*((1-abs(s))*.23+.20)*width
            return root.lerp(tip,t)+outward*(ridge+.059*length*math.sin(math.pi*t))+across*(s*width*wr)
        for i in range(12):
            for j in range(4):
                p=[vertex(i,j),vertex(i+1,j),vertex(i+1,j+1),vertex(i,j+1)]
                part.face(p,color,smooth=True)
                part.face([p0-outward*.052 for p0 in reversed(p)],color,smooth=True)

    def corner_crest(self, sx, sy):
        normal=Vector((sx,sy,0)).normalized()
        base=Vector((sx*(WIDTH/2-1.26),sy*(LENGTH/2-1.24),41.36))
        inward_a=Vector((-sx,0,0))
        inward_b=Vector((0,-sy,0))
        for direction,other in ((inward_a,inward_b),(inward_b,inward_a)):
            for i in range(9):
                root = base + direction*(i*.81) + other*.45
                tip = root + direction*(1.5+i*.45) + other*(.24+i*.12) + UP*(9.49-i*.84)
                self.leaf(self.crest,root,tip,1.19-i*.048,-other,"crest" if i%3 else "green")
            for i in range(4):
                root=base+direction*(1.2+i*1.21)
                tip=root+direction*(1.7+i*.51)+other*.61+UP*(6.4-i*.77)
                self.leaf(self.crest,root,tip,.93,-other,"crest")
        self.leaf(self.crest,base-normal*.11,base-normal*1.04+UP*11.51,1.58,normal,"crest")
        self.owl(base+normal*.43+UP*1.26,normal,3.6576,False)

    def fan_crest(self,side,u,z,state):
        origin=side.point(u,z,-.9)
        along=Vector(side.tangent)
        normal=Vector(side.normal)
        for sign in (-1,1):
            for i in range(8):
                root=origin+along*sign*(.51+i*.42)+UP*(.27-i*.082)
                reach=sign*(1+.81*i)
                height=(6.08 if state else 4.93)-i*.42
                tip=root+along*reach+UP*height-normal*(.28+.069*i)
                self.leaf(self.crest,root,tip,.81+i*.024,normal,"crest" if i%3 else "green")
        for i in (-1,0,1):
            self.leaf(self.crest,origin,origin+along*i*1.70+UP*(6.15-abs(i)*.45)-normal*.68,
                      .87,normal,"crest")
        if state:
            self.owl(side.point(0,z-.02,-1.04),normal,6.096,True)

    def owl(self,origin,normal,height,horned):
        tangent=Vector((-normal.y,normal.x,0))
        basis=(tangent,-normal,UP)
        def p(x,y,z):
            return origin+height*(tangent*x+normal*y+UP*z)
        self.crest.ellipsoid(p(0,.016,.465),basis,(height*.177,height*.115,height*.34),"green",18,11)
        self.crest.ellipsoid(p(0,.077,.72),basis,(height*.196,height*.123,height*.149),"crest",18,11)
        self.crest.ellipsoid(p(0,.116,.46),basis,(height*.141,height*.053,height*.191),"crest",16,9)
        for sign in (-1,1):
            self.crest.ellipsoid(p(sign*.081,.181,.724),basis,(height*.092,height*.031,height*.093),"crest",15,7)
            self.crest.ellipsoid(p(sign*.078,.209,.744),basis,(height*.029,height*.018,height*.035),"dark",10,6)
            self.crest.ellipsoid(p(sign*.079,.222,.753),basis,(height*.014,height*.007,height*.017),"book",7,5)
            if horned:
                self.leaf(self.crest,p(sign*.118,.09,.79),p(sign*.177,.086,.972),height*.059,normal,"green",False)
            self.leaf(self.crest,p(sign*.032,.216,.766),p(sign*.157,.161,.808),height*.040,normal,"green",False)
            for i in range(8):
                arm=p(sign*(.097+.017*i),.001,.614-i*.020)
                if horned:
                    wingtip=p(sign*(.496-.017*i),-.105+.011*i,.927-i*.078)
                else:
                    wingtip=p(sign*(.285-.006*i),-.071,.807-i*.062)
                self.leaf(self.crest,arm,wingtip,height*(.081-.005*i),normal,"crest" if i%2 else "green",False)
            self.crest.pipe(p(sign*.09,.053,.29),p(sign*.109,.185,.12),height*.021,"green",7)
            for i in (-1,0,1):
                self.crest.pipe(p(sign*.109,.185,.12),p(sign*.109+i*.037,.243,.105),height*.015,"crest",6)
        self.leaf(self.crest,p(0,.196,.731),p(0,.255,.635),height*.046,normal,"brass",False)
        if horned:
            for sign in (-1,1):
                self.crest.face([p(0,.24,.104),p(sign*.174,.226,.089),p(sign*.173,.210,.232),p(0,.198,.246)],
                                "book")
            self.crest.pipe(p(0,.244,.102),p(0,.200,.246),height*.013,"dark",6)
