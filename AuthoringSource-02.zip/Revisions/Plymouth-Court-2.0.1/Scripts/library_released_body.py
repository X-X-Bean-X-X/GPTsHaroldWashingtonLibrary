"""Mount the released exterior and its exact pane positions under the new roof."""
import json

import bpy

from library_mesh import MeshPart, clip
from library_rooms import build_curtain_rooms


RELEASED_MESHES = {
    "01 masonry shell and stone courses",
    "02 arched facades and entrance surrounds",
    "03 retained facade mullions",
    "04 retained facade stonework",
    "05 continuous copper roof LOD0",
}
WEST_GLASS_HEIGHTS = (9.84, 37.50)


def halfspace(poly, axis, limit, above):
    out=[]
    for a,b in zip(poly,poly[1:]+poly[:1]):
        inside_a = a[axis]>=limit if above else a[axis]<=limit
        inside_b = b[axis]>=limit if above else b[axis]<=limit
        if inside_a:
            out.append(a)
        if inside_a!=inside_b:
            t=(limit-a[axis])/(b[axis]-a[axis])
            out.append(tuple(u+t*(v-u) for u,v in zip(a,b)))
    return out


def subtract_opening(poly, box):
    """Remove one rectangular glass opening while retaining the source UVs."""
    u0,z0,u1,z1=box
    if (max(p[1] for p in poly)<=u0 or min(p[1] for p in poly)>=u1
        or max(p[2] for p in poly)<=z0 or min(p[2] for p in poly)>=z1):
        return [poly]
    left=halfspace(poly,1,u0,False)
    right=halfspace(poly,1,u1,True)
    middle=halfspace(halfspace(poly,1,u0,True),1,u1,False)
    sill=halfspace(middle,2,z0,False)
    head=halfspace(middle,2,z1,True)
    return [face for face in (left,right,sill,head) if len(face)>=3]


def copy_mesh(obj, west_distance, crown_height, openings):
    part=MeshPart("Released | "+obj.name,atlas=False)
    coord=[obj.matrix_world@v.co for v in obj.data.vertices]
    uvmap=obj.data.uv_layers.active.data
    sill, head = WEST_GLASS_HEIGHTS
    arches = obj.name.startswith("02 ")
    mullions = obj.name.startswith("03 ")
    for face in obj.data.polygons:
        poly=[(coord[v].x,-coord[v].y,coord[v].z,*uvmap[index].uv)
              for v,index in zip(face.vertices,face.loop_indices)]
        if obj.name.startswith("05 "):
            poly=halfspace(poly,2,crown_height,False)
            if len(poly)<3:
                continue
        x0=min(v[0] for v in poly)
        x1=max(v[0] for v in poly)
        west_plane=x1-x0 < .001 and -west_distance-.176 < x0 < -west_distance+.012
        # Both long sides already have the same granite shell and roof cornice.
        # Reflect the State Street entry surrounds and mullions onto that west base.
        if (arches or mullions) and x0 > west_distance + .13 and max(v[2] for v in poly) < sill:
            mirrored = list(reversed(poly))
            part.face([(-x,-u,z) for x,u,z,_,_ in mirrored],
                      uv=[(s,t) for _,_,_,s,t in mirrored],smooth=face.use_smooth)
        if mullions and x1 < -west_distance - .13:
            poly = halfspace(halfspace(poly, 2, sill, True), 2, head, False)
            if len(poly) < 3:
                continue
        # The released glazed plates and hidden brick backing occupy separate planes.
        if west_plane and arches and abs(x0+west_distance+.16)<.004:
            if max(v[2] for v in poly)>2 and min(v[2] for v in poly)<41:
                continue
        pieces=[poly]
        if west_plane and obj.name.startswith("01 "):
            bounds=(min(v[1] for v in poly),min(v[2] for v in poly),max(v[1] for v in poly),max(v[2] for v in poly))
            for box in openings:
                if bounds[0]<box[2] and bounds[2]>box[0] and bounds[1]<box[3] and bounds[3]>box[1]:
                    pieces=[piece for candidate in pieces for piece in subtract_opening(candidate,box)]
        for vertices in pieces:
            part.face([(x,-u,z) for x,u,z,_,_ in vertices],
                      uv=[(s,t) for _,_,_,s,t in vertices],smooth=face.use_smooth)
    return part


def load_released_body(exterior, project, sides, west, crown_height):
    geometry=project/"Source"/"X_Bean_X_HaroldWashingtonLibrary_v007.blend"
    windows=project/"Validation"/"window-layout-v008.json"
    with bpy.data.libraries.load(str(geometry),link=False) as (source, dest):
        if not RELEASED_MESHES.issubset(source.objects):
            raise RuntimeError("The released library source does not contain the expected exterior meshes.")
        dest.objects=[name for name in source.objects if name in RELEASED_MESHES]
    nodes=dest.objects
    by_side={s.short:s for s in sides}
    original=json.loads(windows.read_text(encoding="utf-8"))["panes"]
    west_panes={}
    for item in original:
        side=by_side[item["side"]]
        name=item["kind"]
        if name=="roof-clerestory-pane":
            continue
        poly=[(sum(p[i]*side.tangent[i] for i in range(3)),p[2]) for p in item["vertices"]]
        if name=="curtain-wall-pane":
            west_panes[(item["col"],item["row"])]=poly
        else:
            d=sum(item["vertices"][0][i]*side.normal[i] for i in range(3))-side.distance
            col,row=item["col"],item["row"]
            key=(col//4,col%4,row//2) if name=="tall-arched-pane" else (col,)
            exterior.pane(side,"arch" if name=="tall-arched-pane" else "base-arch",key,
                          poly,d-.010,solid=False)
            if side.short == "E" and name == "small-arched-window":
                reflected = [(-u,z) for u,z in reversed(poly)]
                exterior.pane(west,"base-arch",key,reflected,d-.010,solid=False)
    columns_count=max(c for c,_ in west_panes)+1
    rows_count=max(r for _,r in west_panes)+1
    assert len(west_panes)==columns_count*rows_count==468
    column_lines=[min(u for u,z in west_panes[c,0])-.06 for c in range(columns_count)]
    column_lines.append(max(u for u,z in west_panes[columns_count-1,0])+.06)
    row_lines=[min(z for _,z in west_panes[0,r])-.06 for r in range(rows_count)]
    row_lines.append(max(z for _,z in west_panes[0,rows_count-1])+.06)
    sill, head = WEST_GLASS_HEIGHTS
    visible_glass = {}
    for key, pane in west_panes.items():
        clipped = clip(clip(pane, 1, sill, True), 1, head, False)
        if clipped:
            visible_glass[key] = clipped
    openings=[(min(u for u,z in p)-.004,min(z for u,z in p)-.004,
               max(u for u,z in p)+.004,max(z for u,z in p)+.004)
              for p in visible_glass.values()]
    exterior.released_parts=[copy_mesh(obj,west.distance,crown_height,openings) for obj in nodes]
    for obj in nodes:
        bpy.data.objects.remove(obj,do_unlink=True)
    exterior.rooms,exterior.clear_glass,room_parts=build_curtain_rooms(
        exterior,west,column_lines,row_lines,released_panes=visible_glass,
        glass_heights=WEST_GLASS_HEIGHTS)
    exterior.parts.extend(room_parts)
