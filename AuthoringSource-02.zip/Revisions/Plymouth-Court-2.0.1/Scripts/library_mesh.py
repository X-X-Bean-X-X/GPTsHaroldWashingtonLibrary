"""Mesh and texture helpers for GPT's Harold Washington Library, X_Bean_X."""
import math
import struct
import zlib

import bpy
import numpy as np
from mathutils import Vector


# The fourth channel of the native mask map is smoothness.
PALETTE = {
    "brick": ((146, 77, 64), .87, .00),
    "band": ((163, 101, 84), .83, .00),
    "reveal": ((129, 62, 50), .84, .00),
    "granite": ((125, 83, 76), .69, .00),
    "rusticated": ((132, 91, 83), .84, .00),
    "terracotta": ((111, 61, 51), .80, .00),
    "green": ((59, 92, 86), .55, .31),
    "crest": ((95, 133, 125), .58, .29),
    "roof": ((107, 145, 130), .58, .26),
    "dark": ((33, 49, 46), .63, .32),
    "glass": ((45, 60, 59), .21, .32),
    "glass-blue": ((55, 72, 75), .22, .29),
    "brass": ((146, 111, 60), .36, .52),
    "book": ((169, 165, 133), .66, .05),
    "shadow": ((29, 29, 29), .87, .00),
    "skylight": ((52, 89, 121), .29, .23),
}
TILE = 512
ATLAS = TILE * 4
BORDER = 5
INDICES = {color: i for i, color in enumerate(PALETTE)}


def save_png(path, width, height, rgba):
    def chunk(tag, content):
        return (struct.pack(">I", len(content)) + tag + content
                + struct.pack(">I", zlib.crc32(tag + content)))
    scan = b"".join(b"\0" + row.tobytes() for row in rgba)
    header = struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)
    path.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", header)
                     + chunk(b"IDAT", zlib.compress(scan, 6)) + chunk(b"IEND", b""))


def make_atlas(folder, stem):
    rng = np.random.default_rng(58927)
    color = np.full((ATLAS, ATLAS, 4), 255, np.uint8)
    normal = np.full_like(color, 255)
    mask = np.zeros_like(color)
    y, x = np.mgrid[:TILE, :TILE].astype(np.float32) / TILE
    grain = rng.normal(0, 1, (TILE, TILE)).astype(np.float32)
    mottling = np.cos(2 * np.pi * (5 * x + 3 * y)) * np.sin(2 * np.pi * (2 * x + 7 * y))
    for name, (rgb, rough, metal) in PALETTE.items():
        row, column = divmod(INDICES[name], 4)
        target = np.s_[row*TILE:(row+1)*TILE, column*TILE:(column+1)*TILE]
        variation = grain * 1.9 + mottling * 3
        height = grain * .025
        if name in {"brick", "reveal"}:
            courses = y * 44
            columns = x * 15 + np.floor(courses) * .5
            row_index = np.floor(courses).astype(int)
            col_index = np.floor(columns).astype(int) % 15
            variation += rng.uniform(-8, 8, (44, 15))[row_index, col_index]
            seam = (courses % 1 < .12) | (columns % 1 < .055)
            height += np.where(seam, -.47, .16)
            variation += np.where(seam, 13, 0)
        elif name in {"granite", "rusticated"}:
            courses = y * (7 if name == "rusticated" else 5)
            columns = x * 5 + (np.floor(courses) % 2) * .5
            seam = (courses % 1 < .026) | (columns % 1 < .018)
            ridge = np.sin(3*np.pi*x*TILE/28 + mottling*1.8) * np.cos(2*np.pi*y*TILE/28)
            variation += grain * 3 + ridge * (3 if name == "granite" else 9)
            variation += np.where(seam, -28, 0)
            height += ridge * .07 + np.where(seam, -.4, 0)
        elif name in {"glass", "glass-blue", "skylight"}:
            variation = ((.7-y) * 16 + np.cos(2*np.pi*(x*.65+y*.22))*4
                         + grain * .32)
            height = np.zeros_like(height)
        elif name in {"green", "crest", "roof", "dark"}:
            variation += np.sin(2*np.pi*(3*x+y)) * 4
            height *= .3
        d_y, d_x = np.gradient(height)
        unit = np.sqrt(1 + d_y*d_y + d_x*d_x)
        color[target][:,:,:3] = np.clip(np.array(rgb) + variation[:,:,None], 0, 255)
        normal[target][:,:,:3] = np.stack((-d_x/unit+1, d_y/unit+1, 1/unit+1), axis=-1)*127.5
        mask[target][:,:,0] = int(metal*255)
        mask[target][:,:,3] = int((1-rough)*255)
    for stem_suffix, bitmap in (("BaseColor", color), ("Normal", normal), ("MaskMap", mask)):
        save_png(folder / f"{stem}_{stem_suffix}.png", ATLAS, ATLAS, bitmap)
    black = np.zeros((32, 32, 4), np.uint8)
    black[:, :, 3] = 255
    save_png(folder / f"{stem}_ControlMask.png", 32, 32, black)


def atlas_material(folder, stem, name="HWL Exterior Materials", normal_strength=.66):
    material = bpy.data.materials.new(name)
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    shader = nodes.get("Principled BSDF")
    for key, loc in [("BaseColor", (-620, 250)), ("MaskMap", (-620, -50)), ("Normal", (-620, -330))]:
        image = bpy.data.images.load(str(folder / f"{stem}_{key}.png"))
        image.colorspace_settings.name = "sRGB" if key == "BaseColor" else "Non-Color"
        image.pack()
        node = nodes.new("ShaderNodeTexImage")
        node.image = image
        node.label = key
        node.location = loc
        if key == "BaseColor":
            links.new(node.outputs["Color"], shader.inputs["Base Color"])
        elif key == "MaskMap":
            channels = nodes.new("ShaderNodeSeparateColor")
            links.new(node.outputs["Color"], channels.inputs["Color"])
            links.new(channels.outputs["Red"], shader.inputs["Metallic"])
            invert = nodes.new("ShaderNodeMath")
            invert.operation = "SUBTRACT"
            invert.inputs[0].default_value = 1.0
            links.new(node.outputs["Alpha"], invert.inputs[1])
            links.new(invert.outputs[0], shader.inputs["Roughness"])
        else:
            normals = nodes.new("ShaderNodeNormalMap")
            normals.inputs["Strength"].default_value = normal_strength
            links.new(node.outputs["Color"], normals.inputs["Color"])
            links.new(normals.outputs["Normal"], shader.inputs["Normal"])
    return material


def clip(poly, axis, limit, keep_above):
    out = []
    for a, b in zip(poly, poly[1:] + poly[:1]):
        inside_a = a[axis] >= limit if keep_above else a[axis] <= limit
        inside_b = b[axis] >= limit if keep_above else b[axis] <= limit
        if inside_a:
            out.append(a)
        if inside_a != inside_b:
            fraction = (limit - a[axis]) / (b[axis] - a[axis])
            out.append(tuple(a[i] + fraction * (b[i] - a[i]) for i in range(2)))
    return out


def clipped_rect(poly, u0, z0, u1, z1):
    for axis, value, greater in ((0, u0, True), (0, u1, False), (1, z0, True), (1, z1, False)):
        poly = clip(poly, axis, value, greater)
        if len(poly) < 3:
            return []
    return poly


def rect(u0, z0, u1, z1):
    return [(u0, z0), (u1, z0), (u1, z1), (u0, z1)]


def atlas_uv(color, u, v):
    row, column = divmod(INDICES[color], 4)
    span = TILE - 2 * BORDER
    return ((column*TILE + BORDER + u*span) / ATLAS,
            ((3-row)*TILE + BORDER + v*span) / ATLAS)


class MeshPart:
    def __init__(self, name, tier=0, atlas=True):
        self.name = name
        self.tier = tier
        self.atlas = atlas
        self.positions = []
        self.index = {}
        self.faces = []
        self.face_keys = set()
        self.uvs = []
        self.smooth = []

    def vertex(self, xyz):
        key = tuple(round(co, 6) for co in xyz)
        existing = self.index.get(key)
        if existing is not None:
            return existing
        result = len(self.positions)
        self.positions.append(key)
        self.index[key] = result
        return result

    def face(self, points, color=None, uv=None, smooth=False):
        ordered = {}
        for j, point in enumerate(points):
            ordered.setdefault(self.vertex(point), j)
        if len(ordered) < 3:
            return
        face = tuple(ordered)
        face_key = tuple(sorted(face))
        if face_key in self.face_keys:
            return
        v0 = Vector(self.positions[face[0]])
        normal = Vector((0, 0, 0))
        for i in range(1, len(face)-1):
            normal += (Vector(self.positions[face[i]])-v0).cross(Vector(self.positions[face[i+1]])-v0)
        if normal.length_squared < 1e-12:
            return
        self.face_keys.add(face_key)
        if uv is None:
            drop = max(range(3), key=lambda axis: abs(normal[axis]))
            axes = [i for i in range(3) if i != drop]
            mins = [min(p[a] for p in points) for a in axes]
            spans = [max(max(p[a] for p in points)-low, 1e-4) for a, low in zip(axes, mins)]
            uv = [tuple((p[a]-low)/span for a, low, span in zip(axes, mins, spans)) for p in points]
        self.faces.append(face)
        self.uvs.append([atlas_uv(color, *uv[j]) if self.atlas else uv[j] for j in ordered.values()])
        self.smooth.append(smooth)

    def box(self, center, axes, size, color):
        c = Vector(center)
        a, b, d = [Vector(axis) * (length / 2) for axis, length in zip(axes, size)]
        verts = [c-a-b-d, c+a-b-d, c+a+b-d, c-a+b-d, c-a-b+d, c+a-b+d, c+a+b+d, c-a+b+d]
        for face in ((3, 2, 1, 0), (4, 5, 6, 7), (0, 1, 5, 4),
                     (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7)):
            self.face([verts[i] for i in face], color)

    def pipe(self, start, end, radius, color, sides=6):
        origin, tip = Vector(start), Vector(end)
        axis = tip - origin
        if axis.length < .0001:
            return
        a = axis.normalized().orthogonal().normalized()
        b = axis.normalized().cross(a)
        ring = [radius*(a*math.cos(2*math.pi*i/sides)+b*math.sin(2*math.pi*i/sides))
                for i in range(sides)]
        for i in range(sides):
            j = (i + 1) % sides
            self.face([origin+ring[i], origin+ring[j], tip+ring[j], tip+ring[i]], color, smooth=True)

    def ellipsoid(self, center, basis, radii, color, sides=12, tiers=7):
        c = Vector(center)
        a, b, d = [Vector(axis)*r for axis, r in zip(basis, radii)]
        def point(i, j):
            across = math.tau*i/sides
            row = -math.pi/2 + math.pi*j/tiers
            return c + (a*math.cos(across) + b*math.sin(across))*math.cos(row) + d*math.sin(row)
        for j in range(tiers):
            for i in range(sides):
                self.face([point(i,j), point(i+1,j), point(i+1,j+1), point(i,j+1)], color, smooth=True)

    def object(self, material, collection):
        mesh = bpy.data.meshes.new(self.name)
        mesh.from_pydata(self.positions, [], self.faces)
        if mesh.validate(verbose=False):
            raise RuntimeError(f"Invalid mesh in {self.name}")
        mesh.update()
        uvmap = mesh.uv_layers.new(name="UVMap")
        for p, coords, smooth in zip(mesh.polygons, self.uvs, self.smooth):
            p.use_smooth = smooth
            for index, point in zip(p.loop_indices, coords):
                uvmap.data[index].uv = point
        mesh.materials.append(material)
        obj = bpy.data.objects.new(self.name, mesh)
        obj["detail_tier"] = self.tier
        collection.objects.link(obj)
        return obj
