"""Static rooms behind the Plymouth Court curtain wall."""
from dataclasses import dataclass
import random

from library_mesh import MeshPart, rect


ROOM_TYPES = (
    "Conference", "Sculpture gallery", "Library stacks", "Lounge", "Kitchen",
    "Office", "Cubicles", "Stairs", "Elevator lobby",
)


@dataclass
class Room:
    key: tuple
    kind: str
    left: float
    right: float
    floor: float
    ceiling: float
    depth: float
    glow: list
    light_position: tuple


class Furniture:
    def __init__(self, side, geometry, left, right, floor, height, depth):
        self.side = side
        self.part = geometry
        self.center = (left+right)/2
        self.width = right-left
        self.floor = floor
        self.height = height
        self.depth = depth

    def box(self, u, d, z, width, depth, height, color):
        self.side.box(self.part,self.center+u,self.floor+z,-d,width,height,depth,color)

    def sphere(self, u, d, z, size, color):
        self.part.ellipsoid(self.side.point(self.center+u,self.floor+z,-d),self.side.axes,size,color,12,7)

    def desk(self, u, d, w=1.36):
        self.box(u,d,.77,w,.76,.085,"brass")
        self.box(u-w*.40,d,.41,.066,.61,.73,"dark")
        self.box(u+w*.40,d,.41,.066,.61,.73,"dark")
        self.box(u+.17,d+.17,1.015,.60,.055,.30,"shadow")
        self.box(u+.17,d+.17,.857,.067,.095,.155,"dark")
        self.box(u-.17,d-.12,.831,.32,.13,.021,"book")

    def chair(self, u, d, back=-1):
        self.box(u,d,.49,.47,.49,.09,"green")
        self.box(u,d+.215*back,.75,.44,.084,.44,"green")
        self.box(u,d,.26,.078,.09,.45,"dark")
        self.box(u,d,.08,.37,.34,.06,"dark")

    def conference(self):
        for u in (-self.width*.21,self.width*.21):
            self.box(u,2.53,.43,.13,1.02,.76,"dark")
        self.box(0,2.50,.82,self.width*.68,1.33,.12,"brass")
        for x in (-.24,-.08,.08,.24):
            for s in (-1,1):
                self.chair(x*self.width,2.5+s*.95,s)
        self.box(.05,self.depth-.31,1.78,self.width*.38,.093,.78,"shadow")
        self.box(.05,self.depth-.365,1.78,self.width*.344,.05,.69,"glass-blue")

    def sculpture(self):
        for j,x in enumerate((-.26,.20)):
            u = self.width*x
            self.box(u,2.08,.39,.87,1.06,.78,"book")
            if j == 0:
                self.sphere(u-.12,2.10,1.37,(.32,.27,.61),"crest")
                self.sphere(u+.21,2.18,1.51,(.28,.32,.42),"brass")
                self.sphere(u+.07,1.85,1.77,(.23,.18,.31),"crest")
            else:
                self.sphere(u,2.06,1.36,(.395,.32,.53),"granite")
                self.sphere(u-.02,2.00,1.85,(.25,.24,.28),"book")
                self.box(u,2.07,.88,.42,.42,.23,"green")

    def books(self):
        colors=("terracotta","book","green","brick","brass","dark")
        rng=random.Random(int(self.center*61+10000)+int(self.floor*13))
        for group,at in enumerate((-.33,0,.33)):
            u=at*self.width
            w=self.width*.271
            self.box(u,2.78,1.20,w,.21,2.43,"brass")
            for s in (-1,1):
                self.box(u+s*w/2,2.55,1.25,.085,.63,2.5,"brass")
            for row in range(4):
                z=.24+row*.55
                self.box(u,2.50,z,w,.68,.064,"brass")
                for col in range(9):
                    width=w/9
                    h=rng.uniform(.29,.467)
                    self.box(u-w/2+(col+.53)*width,2.39,z+.04+h/2,
                             width*.78,.30,h,colors[(row*7+col+group*2)%len(colors)])
        self.box(0,1.40,.33,self.width*.24,.62,.64,"green")

    def lounge(self):
        for u,d in ((-self.width*.22,2.68),(self.width*.24,3.03)):
            self.box(u,d,.46,1.63,.77,.23,"green")
            self.box(u,d+.34,.72,1.6,.18,.55,"green")
            for s in (-1,1):
                self.box(u+s*.76,d,.59,.15,.68,.33,"crest")
        self.box(0,1.66,.47,1.30,.69,.09,"brass")
        self.box(0,1.66,.26,.87,.43,.39,"dark")
        self.box(-.28,1.63,.53,.29,.22,.035,"book")

    def kitchen(self):
        w=self.width*.72
        a=-self.width*.05
        back=self.depth-.69
        self.box(a,back,.46,w,.82,.91,"book")
        self.box(a,back,.96,w+.055,.92,.10,"dark")
        self.box(a,back,1.77,w,.36,.55,"green")
        self.box(a-w*.19,back,.999,.67,.52,.025,"shadow")
        self.box(a+w*.16,back,.994,.52,.30,.024,"glass-blue")
        self.box(a+w*.16,back+.17,1.16,.06,.06,.35,"brass")
        self.box(self.width*.39,back,1.02,.69,.76,2.03,"crest")
        for j in range(6):
            u=a-w/2+(j+.5)*w/6
            self.box(u,back-.422,.69,.24,.053,.040,"dark")

    def office(self,cubicles):
        for x in (-.26,0,.26):
            u=x*self.width
            self.desk(u,2.56,1.19 if cubicles else 1.38)
            self.chair(u,1.93,-1)
            if cubicles:
                self.box(u,2.99,1.08,self.width*.246,.063,.94,"glass-blue")
                self.box(u-self.width*.127,2.48,1.08,.063,.94,.94,"crest")
            else:
                self.box(u,3.66,1.32,.88,.34,2.42,"brass")
                for z in (.43,.95,1.63):
                    self.box(u,3.43,z,.81,.21,.057,"book")

    def stairs(self):
        run=self.width*.67
        rise=self.height*.68
        n=13
        for i in range(n):
            u=-run/2+(i+.50)*run/n
            total=(i+1)*rise/n
            self.box(u,2.59,total/2,run/n+.011,1.33,total,"granite")
            self.box(u,2.58,total,run/n+.018,1.38,.051,"book")
            if i % 2 == 0:
                self.box(u,1.90,total+.41,.05,.065,.84,"green")
        a=self.side.point(self.center-run*.49,self.floor+.88,-1.90)
        b=self.side.point(self.center+run*.48,self.floor+.86+rise,-1.90)
        self.part.pipe(a,b,.035,"brass",6)
        self.box(run*.57,2.59,rise-.088,run*.16,1.37,.174,"granite")

    def elevators(self):
        for x in (-.20,.20):
            u=x*self.width
            w=self.width*.29
            d=self.depth-.48
            self.box(u,d,1.21,w,.33,2.42,"shadow")
            for s in (-1,1):
                self.box(u+s*(w*.233+.014),d-.177,1.14,w*.46,.087,2.26,"crest")
            self.box(u+w*.59,d-.20,1.23,.14,.060,.26,"brass")
            self.box(u,d-.18,2.51,.34,.035,.113,"dark")
        self.box(.13,1.43,.29,self.width*.37,.63,.56,"green")

    def populate(self,kind):
        if self.height < 2.55 and kind in {"Stairs","Elevator lobby","Library stacks","Office","Cubicles"}:
            self.sculpture()
            return "Sculpture gallery"
        if kind=="Conference":
            self.conference()
        elif kind=="Sculpture gallery":
            self.sculpture()
        elif kind=="Library stacks":
            self.books()
        elif kind=="Lounge":
            self.lounge()
        elif kind=="Kitchen":
            self.kitchen()
        elif kind in {"Office","Cubicles"}:
            self.office(kind=="Cubicles")
        elif kind=="Stairs":
            self.stairs()
        elif kind=="Elevator lobby":
            self.elevators()
        return kind


def build_curtain_rooms(exterior, side, columns, rows, released_panes=None, glass_heights=None):
    bounds = ([0,2,5,7,10,12,15,18,20,23,26,28,31,34,36] if released_panes else
              [0,5,10,15,21,26,31,36,42,47,52,58,63,68])
    floors = ([0,2,4,5,7,9,10,12,13] if released_panes else
              [*range(0,len(rows)-1,2),len(rows)-1])
    shell=MeshPart("08 West room floors, ceilings and rear walls")
    furniture=MeshPart("09 Static west interiors",1)
    review_glass=MeshPart("Plymouth Court clear glass",atlas=False)
    rooms=[]
    rng=random.Random(638320)
    for floor,(r0,r1) in enumerate(zip(floors,floors[1:])):
        z0,z1=rows[r0],rows[r1]
        if glass_heights:
            z0 = max(z0, glass_heights[0])
            z1 = min(z1, glass_heights[1])
        for column,(c0,c1) in enumerate(zip(bounds,bounds[1:])):
            # Consume the same room selection for removed levels as for visible ones.
            kind=ROOM_TYPES[(column*5+floor*4+rng.randrange(0,3))%len(ROOM_TYPES)]
            if z0 >= z1:
                continue
            edge=side.width/2-.17
            u0,u1=max(columns[c0],-edge),min(columns[c1],edge)
            width=u1-u0
            center=(u0+u1)/2
            depth=4.65 if column % 3 else 5.18
            floor_color=("brass","granite","shadow")[floor%3]
            side.box(shell,center,z0+.057,-depth/2,width,.107,depth,floor_color)
            side.box(shell,center,z1-.083,-depth/2,width,.143,depth,"book")
            side.box(shell,center,(z0+z1)/2,-depth,width,z1-z0,.137,"granite")
            side.vertical(shell,u0,z0+.13,z1-.16,-depth/2,.138,depth,"book")
            if column == len(bounds)-2:
                side.vertical(shell,u1,z0+.13,z1-.16,-depth/2,.138,depth,"book")
            key=(floor,column)
            room=Furniture(side,furniture,u0+.07,u1-.07,z0+.098,z1-z0-.24,depth)
            kind=room.populate(kind)
            glow=[]
            # A softly lit rear wall and ceiling luminaire leave the furniture in front.
            rear=rect(u0+.132,z0+.145,u1-.132,z1-.166)
            glow.append(tuple(tuple(side.point(u,z,-depth+.081)) for u,z in rear))
            light_x0,light_x1=center-width*.31,center+width*.31
            light_z=z1-.163
            glow.append(tuple(tuple(side.point(u,light_z,d)) for u,d in
                               [(light_x0,-1.48),(light_x0,-1.75),(light_x1,-1.75),(light_x1,-1.48)]))
            rooms.append(Room(key,kind,u0,u1,z0,z1,depth,glow,
                              tuple(side.point(center,min(z1-.32,z0+3.3),-1.43))))
            for c in range(c0,c1):
                for r in range(r0,r1):
                    if released_panes is not None:
                        field = released_panes.get((c,r))
                        if not field:
                            continue
                        offset=.160
                    else:
                        field=rect(columns[c]+.055,rows[r]+.069,columns[c+1]-.055,rows[r+1]-.069)
                        offset=-.054
                    exterior.pane(side,"curtain",key,field,offset,solid=False)
                    review_glass.face([side.point(u,z,offset) for u,z in field])
    return rooms, review_glass, [shell,furniture]
