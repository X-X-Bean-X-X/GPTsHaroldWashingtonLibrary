"""Build and render the Harold Washington Library redesign using Blender 5.2."""
import argparse
from collections import Counter
import hashlib
from itertools import accumulate
import json
import math
from pathlib import Path
import random
import shutil
import sys

import bmesh
import bpy
import numpy as np
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "Scripts"))
from library_mesh import MeshPart, atlas_material, make_atlas, save_png
from library_exterior import BRICK_SIDES, CORNICE, EAST, LENGTH, NORTH, SOUTH, WEST, WIDTH, Exterior
from library_released_body import WEST_GLASS_HEIGHTS

STEM = "HaroldWashingtonLibraryRedesign"
AUTHOR = "X_Bean_X"
RELEASE_VERSION = "2.0.1"
STAGE_SECONDS = (37, 53, 71)
STAGES = ((0, 2, 5, 7), (1, 2, 4, 8), (0, 3, 6, 9))
PREVIOUS_LIGHT_LAYOUT = 1
BASE = ROOT / "Import" / STEM
REVIEW = ROOT / "Review"
BUILD = ROOT / "Validation"
REVIEW_TEXTURES = ROOT / "Source" / "PreviewMaterials"
COVER_TEXTURES = ROOT / "Source" / "CoverMaterials"
RELEASED = ROOT.parents[3] / "Completed" / "GPT's Harold Washington Library"
RELEASED_TEXTURES = RELEASED / "Textures" / "V007"


def collection(name):
    result = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(result)
    return result


def material(name, color, roughness=.5, energy=0):
    result = bpy.data.materials.new(name)
    result.diffuse_color = (*color,1)
    result.use_nodes = True
    shader = result.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = (*color,1)
    shader.inputs["Roughness"].default_value = roughness
    shader.inputs["Emission Color"].default_value = (*color,1)
    shader.inputs["Emission Strength"].default_value = energy
    return result


def review_glass():
    glass=material("Clear green-gray glass | Blender review",(.11,.17,.15),.20)
    nodes=glass.node_tree.nodes
    links=glass.node_tree.links
    transparent=nodes.new("ShaderNodeBsdfTransparent")
    transparent.inputs["Color"].default_value=(.88,.94,.92,1)
    mix=nodes.new("ShaderNodeMixShader")
    mix.inputs[0].default_value=.17
    links.new(transparent.outputs[0],mix.inputs[1])
    links.new(nodes.get("Principled BSDF").outputs[0],mix.inputs[2])
    links.new(mix.outputs[0],nodes.get("Material Output").inputs["Surface"])
    return glass


def seed(text):
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:8], "little")


def pattern_for_window(exterior):
    keys = sorted({(p.side,p.section,p.cluster) for p in exterior.panes}, key=str)
    target = {s for s in (r.kind for r in exterior.rooms)}
    arches={}
    arch_rows={}
    for p in exterior.panes:
        if p.section == "arch":
            arches.setdefault((p.side,p.cluster[0]),[]).append((p.side,p.section,p.cluster))
            group=(p.side,p.cluster[0],p.cluster[2])
            arch_rows.setdefault(group,[]).append((p.side,p.section,p.cluster))
    for attempt in range(192):
        index={}
        for entry in keys:
            side,section,cluster=entry
            if section=="arch":
                bay,column,tier=cluster
                strip=(4,2,0,6)
                # Neighboring columns stay luminous the full length of the arch.
                # A few floor groups exchange the warm side to avoid a repeated stripe.
                flip=(seed(f"arch wash/{side}/{bay}") % 2)==1
                if tier in (2,3) and seed(f"arch room/{side}/{bay}") % 3==0:
                    flip=not flip
                index[entry]=strip[3-column if flip else column]
                continue
            # Keep all of v5's surviving room and window assignments.
            layout = attempt if side=="W" and section in ("base-arch","gable") else PREVIOUS_LIGHT_LAYOUT
            rng=random.Random(seed(f"{entry}/{layout}/hwl-redesign"))
            weights=(1.32,1,1.32,.95,1,1,1,.86,1,1)
            index[entry]=rng.choices(range(10),weights,k=1)[0]
        counts={}
        for side in ("E","N","S","W"):
            members=[p for p in exterior.panes if p.side==side]
            counts[side] = {"panes":len(members),
                            "lit":[sum(p.section=="arch" or index[(p.side,p.section,p.cluster)] in stage
                                       for p in members) for stage in STAGES]}
        total=sum(row["panes"] for row in counts.values())
        stage_shares=[sum(row["lit"][phase] for row in counts.values())/total for phase in range(3)]
        west=counts["W"]
        west_rooms=[{r.kind for r in exterior.rooms if index[("W","curtain",r.key)] in stage}
                    for stage in STAGES]
        arch_reads=all(sum(index[key] in stage for key in panes) >= 4
                       for panes in arches.values() for stage in STAGES)
        continuous=all(any(index[key] in stage for key in panes)
                       for panes in arch_rows.values() for stage in STAGES)
        if (all(.30<=portion<=.595 for portion in stage_shares)
            and all(.335<=lit/west["panes"]<=.565 for lit in west["lit"])
            and all(set(types)==target for types in west_rooms) and arch_reads and continuous):
            return index, counts
    raise RuntimeError("Could not find three stages with adequate distribution on all four sides")


def projection(face, room=False, ceiling=False):
    if ceiling:
        return [(u,.97) for u in (.10,.10,.90,.90)]
    zmin=min(p[2] for p in face)
    zmax=max(p[2] for p in face)
    along=0 if (max(p[0] for p in face)-min(p[0] for p in face))>1e-5 else 1
    umin=min(p[along] for p in face)
    umax=max(p[along] for p in face)
    if room:
        return [(.06+.88*(p[along]-umin)/max(umax-umin,1e-4),
                 .576+.365*(p[2]-zmin)/max(zmax-zmin,1e-4)) for p in face]
    return [(.06+.88*(p[along]-umin)/max(umax-umin,1e-4),
             .059+.397*(p[2]-zmin)/max(zmax-zmin,1e-4)) for p in face]


def write_overlay_maps(folder, name):
    size=128
    yy,xx=np.mgrid[:size,:size]/(size-1)
    v=1-yy
    local_y=np.clip(2*v,0,1)
    horizontal=np.sin(xx*np.pi)**.71
    vertical=np.sin(local_y*np.pi)**.42
    glass=.46+.46*horizontal*(.73+.27*vertical)
    wall=.135+.16*np.exp(-abs(v-.90)*8)+.13*np.sin(xx*np.pi)**2
    em=np.clip(np.where(v<.5,glass,wall),0,1)
    luminaire=v>.943
    em=np.where(luminaire,1,em)
    emissive=np.full((size,size,4),255,dtype=np.uint8)
    emissive[:,:,:3]=np.stack((em,.91*em,.76*em),axis=-1)*255
    save_png(folder / f"{name}_Emissive.png",size,size,emissive)
    colors=np.full_like(emissive,255)
    colors[:,:,:3] = np.where((v<.5)[:,:,None], (44,59,58), (124,83,76))
    save_png(folder / f"{name}_BaseColor.png",size,size,colors)
    for suffix,rgba in (("MaskMap",(0,0,0,70)),("Normal",(128,128,255,255)),("ControlMask",(0,0,0,255))):
        bitmap=np.tile(np.array(rgba,dtype=np.uint8),(16,16,1))
        save_png(folder / f"{name}_{suffix}.png",16,16,bitmap)


def overlays(exterior, group_for, root_collection):
    results=[]
    arch_meshes=[]
    arch_material=material("Night | soft amber window panes",(.82,.35,.099),.46,1.27)
    if (texture:=REVIEW_TEXTURES / "preview_Emissive.png").exists():
        img=bpy.data.images.load(str(texture),check_existing=True)
        img.pack()
        tree=arch_material.node_tree
        tex=tree.nodes.new("ShaderNodeTexImage")
        tex.image=img
        shade=tree.nodes.new("ShaderNodeMixRGB")
        shade.blend_type="MULTIPLY"
        shade.inputs[0].default_value=1
        shade.inputs[2].default_value=(1.0,.60,.252,1)
        tree.links.new(tex.outputs["Color"],shade.inputs[1])
        tree.links.new(shade.outputs[0],tree.nodes.get("Principled BSDF").inputs["Emission Color"])
    room_material=material("Night | warm west room walls",(.40,.214,.084),.74,.30)
    ceiling_material=material("Night | west ceiling fixtures",(1.,.62,.29),.46,.87)
    for gid in range(10):
        full=MeshPart(f"HWLRedesignNightG{gid}",atlas=False)
        arched=MeshPart(f"HWLRedesignArchG{gid}",atlas=False)
        preview=[MeshPart(f"G{gid} amber windows",atlas=False),
                 MeshPart(f"G{gid} lit west walls",atlas=False),
                 MeshPart(f"G{gid} ceiling luminaires",atlas=False)]
        for p in exterior.panes:
            if p.section=="curtain" or group_for[(p.side,p.section,p.cluster)]!=gid:
                continue
            uv=projection(p.world)
            (arched if p.section=="arch" else full).face(p.world,uv=uv)
            preview[0].face(p.world,uv=uv)
        for room in exterior.rooms:
            if group_for[("W","curtain",room.key)]!=gid:
                continue
            for ceiling,face in enumerate(room.glow):
                uv=projection(face,room=True,ceiling=bool(ceiling))
                full.face(face,uv=uv)
                preview[1+ceiling].face(face,uv=uv)
        mats=(arch_material,room_material,ceiling_material)
        results.append((full,[mesh.object(mat,root_collection) for mesh,mat in zip(preview,mats)]))
        if arched.faces:
            arch_meshes.append((gid,arched))
    return results,arch_meshes


def export(path, objects):
    bpy.ops.object.select_all(action="DESELECT")
    for obj in objects:
        obj.hide_set(False)
        obj.select_set(True)
    bpy.context.view_layer.objects.active=objects[0]
    bpy.ops.export_scene.fbx(
        filepath=str(path),use_selection=True,object_types={"MESH"},global_scale=1,
        apply_unit_scale=True,apply_scale_options="FBX_SCALE_NONE",axis_forward="-Z",axis_up="Y",
        bake_space_transform=True,use_mesh_modifiers=True,mesh_smooth_type="FACE",
        use_tspace=True,add_leaf_bones=False,bake_anim=False,path_mode="AUTO",use_custom_props=True)


def triangulate_export(obj):
    bpy.context.view_layer.objects.active=obj
    modifier=obj.modifiers.new("FBX triangle faces","TRIANGULATE")
    bpy.ops.object.modifier_apply(modifier=modifier.name)
    mesh=bmesh.new()
    mesh.from_mesh(obj.data)
    bmesh.ops.dissolve_degenerate(mesh,dist=.000012,edges=list(mesh.edges))
    bmesh.ops.triangulate(mesh,faces=list(mesh.faces))
    tiny=[face for face in mesh.faces if face.calc_area()<2e-9]
    if tiny:
        bmesh.ops.delete(mesh,geom=tiny,context="FACES_ONLY")
    mesh.to_mesh(obj.data)
    mesh.free()
    obj.data.validate(verbose=False,clean_customdata=False)
    obj.data.update()


def texture_pixels(path):
    image=bpy.data.images.load(str(path),check_existing=False)
    image.colorspace_settings.name="Non-Color"
    image.alpha_mode="CHANNEL_PACKED"
    width,height=image.size
    values=np.empty(width*height*4,dtype=np.float32)
    image.pixels.foreach_get(values)
    bpy.data.images.remove(image)
    rgba=np.rint(values.reshape((height,width,4))[::-1]*255).astype(np.uint8)
    if width!=2048 or height!=2048:
        rows=(np.arange(2048)*height)//2048
        cols=(np.arange(2048)*width)//2048
        rgba=rgba[rows[:,None],cols[None,:]]
    return rgba


def merge_exterior_atlases():
    # Repack the two unchanged sets of tiles into one native material.
    for channel in ("BaseColor","Normal","MaskMap","ControlMask"):
        cover=texture_pixels(COVER_TEXTURES / f"{STEM}_{channel}.png")
        original=texture_pixels(RELEASED_TEXTURES / f"HWL_{channel}.png")
        save_png(BASE / f"{STEM}_{channel}.png",4096,2048,np.concatenate((cover,original),axis=1))


def output_native_inputs(building, light_overlays, arch_meshes, steady_mesh, scene_glass, material):
    export_collection=collection("Temporary FBX export meshes")
    # The review model keeps every carved leaf and prop. The native meshes
    # spend that detail by distance, with the window planes intact at every LOD.
    budgets=(
        {"04":.78, "07":.31},
        {"01":.87, "03":.53, "04":.26, "05":.46, "06":.21, "09":.19, "10":.56},
        {"01":.37, "03":.26, "04":.078, "08":.40, "10":.29},
    )
    lods=[]
    for lod,tier in ((0,2),(1,1),(2,0)):
        name=STEM if not lod else f"{STEM}_LOD{lod}"
        objects=[]
        for obj in building:
            if obj["detail_tier"]<=tier:
                item=obj.copy()
                item.data=obj.data.copy()
                export_collection.objects.link(item)
                uv_offset=.5 if obj.get("released_exterior") else 0
                for loop in item.data.uv_layers.active.data:
                    loop.uv.x=loop.uv.x*.5+uv_offset
                item.data.materials.clear()
                item.data.materials.append(material)
                ratio=budgets[lod].get(obj.name[:2])
                if ratio is not None:
                    modifier=item.modifiers.new("Reduce detail for game distance","DECIMATE")
                    modifier.ratio=ratio
                    modifier.use_collapse_triangulate=True
                    bpy.context.view_layer.objects.active=item
                    bpy.ops.object.modifier_apply(modifier=modifier.name)
                objects.append(item)
        bpy.ops.object.select_all(action="DESELECT")
        for item in objects:
            item.select_set(True)
        bpy.context.view_layer.objects.active=objects[0]
        bpy.ops.object.join()
        obj=bpy.context.object
        obj.name=name
        triangulate_export(obj)
        export(BASE / f"{name}.fbx",[obj])
        dimensions=[[min(v.co[i] for v in obj.data.vertices) for i in range(3)],
                    [max(v.co[i] for v in obj.data.vertices) for i in range(3)]]
        lods.append(dict(lod=lod,filename=f"{name}.fbx",vertices=len(obj.data.vertices),
                         triangles=len(obj.data.polygons),bounds=dimensions))
        if lod:
            for key in ("BaseColor","Normal","MaskMap","ControlMask"):
                shutil.copyfile(BASE / f"{STEM}_{key}.png",BASE / f"{name}_{key}.png")
        bpy.data.objects.remove(obj,do_unlink=True)

    for mesh in [shape for shape,_ in light_overlays]+[shape for _,shape in arch_meshes]+[steady_mesh]:
        folder=ROOT / "Import" / mesh.name
        folder.mkdir(exist_ok=True,parents=True)
        obj=mesh.object(material,export_collection)
        triangulate_export(obj)
        export(folder / f"{mesh.name}.fbx",[obj])
        write_overlay_maps(folder,mesh.name)
        bpy.data.objects.remove(obj,do_unlink=True)
    # Authored separately to allow the native editor to assign a transparent glazing surface.
    export(ROOT / "Import" / "PlymouthCourtGlass.fbx",[scene_glass])
    bpy.data.collections.remove(export_collection)
    return lods


def add_light(rig,name,kind,position,color,energy,target=None,radius=1):
    data=bpy.data.lights.new(name,kind)
    data.energy=energy
    data.color=color
    obj=bpy.data.objects.new(name,data)
    rig.objects.link(obj)
    obj.location=position
    if target is not None:
        obj.rotation_euler=(Vector(target)-obj.location).to_track_quat("-Z","Y").to_euler()
    if kind=="POINT":
        data.shadow_soft_size=radius
    if kind=="AREA":
        data.shape="DISK"
        data.size=radius
    if kind=="SPOT":
        data.spot_blend=.80
        data.spot_size=math.radians(87)
        data.shadow_soft_size=radius
    return obj


def make_rig(exterior, group_for):
    rig=collection("Review only | daylight and night lighting")
    ground=MeshPart("Review only | damp stone around building",atlas=False)
    ground.face([(-490,-490,-.038),(490,-490,-.038),(490,490,-.038),(-490,490,-.038)],
                uv=[(0,0),(1,0),(1,1),(0,1)])
    wet=material("Review paving | damp stone",(.076,.062,.058),.36)
    tree=wet.node_tree
    noise=tree.nodes.new("ShaderNodeTexNoise")
    noise.inputs["Scale"].default_value=5.5
    noise.inputs["Detail"].default_value=3
    coords=tree.nodes.new("ShaderNodeTexCoord")
    tree.links.new(coords.outputs["Object"],noise.inputs["Vector"])
    ramp=tree.nodes.new("ShaderNodeValToRGB")
    ramp.color_ramp.elements[0].color=(.042,.047,.052,1)
    ramp.color_ramp.elements[1].color=(.099,.079,.071,1)
    tree.links.new(noise.outputs["Fac"],ramp.inputs[0])
    shader=tree.nodes.get("Principled BSDF")
    shader.inputs["Coat Weight"].default_value=.16
    joints=tree.nodes.new("ShaderNodeTexBrick")
    joints.inputs["Scale"].default_value=1.0
    joints.inputs["Brick Width"].default_value=1.09
    joints.inputs["Row Height"].default_value=.66
    joints.inputs["Mortar Size"].default_value=.024
    joints.inputs["Mortar Smooth"].default_value=.06
    joints.inputs["Color1"].default_value=(.085,.071,.065,1)
    joints.inputs["Color2"].default_value=(.057,.052,.052,1)
    joints.inputs["Mortar"].default_value=(.026,.024,.026,1)
    tree.links.new(coords.outputs["Object"],joints.inputs["Vector"])
    combine=tree.nodes.new("ShaderNodeMixRGB")
    combine.blend_type="MULTIPLY"
    combine.inputs[0].default_value=.35
    tree.links.new(joints.outputs["Color"],combine.inputs[1])
    tree.links.new(ramp.outputs[0],combine.inputs[2])
    tree.links.new(combine.outputs[0],shader.inputs["Base Color"])
    bump=tree.nodes.new("ShaderNodeBump")
    bump.inputs["Strength"].default_value=.33
    bump.inputs["Distance"].default_value=.015
    bump.invert=True
    tree.links.new(joints.outputs["Fac"],bump.inputs["Height"])
    tree.links.new(bump.outputs[0],shader.inputs["Normal"])
    ground.object(wet,rig)
    sun=add_light(rig,"Daylight","SUN",(35,-50,108),(1,.879,.772),2.55,(0,0,0))
    sun.data.angle=.105
    moon=add_light(rig,"Cool night sky direction","SUN",(58,-31,128),(.66,.78,1),.84,(0,0,0))
    moon.data.angle=.12
    hardware=MeshPart("Preview lantern lenses",atlas=False)
    roof_panels=MeshPart("Preview steady arch and skylight glow",atlas=False)
    steady=MeshPart("HWLRedesignNightSteady",atlas=False)
    exterior_lights=[]
    native_fixture_plan=[]
    for direction,u,z,main in exterior.lanterns:
        side={"E":EAST,"N":NORTH,"S":SOUTH,"W":WEST}[direction]
        near=side.point(u,z-.115,.70)
        down_target=side.point(u,0,3.20 if main else 2.62)
        up_target=side.point(u,9.25 if side==WEST else z+6.6,.09)
        pavement=add_light(rig,f"{side.short} pavement {u:.1f}","SPOT",near,
                           (1,.548,.254),2370 if main else 1710,down_target,.25)
        pavement.data.spot_size=math.radians(104)
        brick=add_light(rig,f"{side.short} brick {u:.1f}","SPOT",near,
                        (1,.444,.147),3900 if main else 2970,up_target,.22)
        brick.data.spot_size=math.radians(64)
        exterior_lights.extend((pavement,brick))
        # A visible practical source softens the two beams directly around the lantern.
        exterior_lights.append(add_light(rig,f"{side.short} lantern {u:.1f}","POINT",near,
                                         (1,.515,.24),500 if main else 320,None,.21))
        native_fixture_plan.append(dict(side=direction,position=list(near),targetPavement=list(down_target),
                                        targetMasonry=list(up_target),kelvin=2700,entryPair=main))
        if side in BRICK_SIDES:
            amber_reflection=add_light(rig,f"{side.short} soft arch reflection {u:.1f}","AREA",
                                      side.point(u,20.3,7.3),(1,.51,.21),1420,
                                      side.point(u,22.6,0),3.8)
            amber_reflection.data.shape="RECTANGLE"
            amber_reflection.data.size_y=18.6
            exterior_lights.append(amber_reflection)
            native_fixture_plan[-1]["archReflection"] = dict(position=list(amber_reflection.location),
                                                               target=list(side.point(u,22.6,0)),
                                                               warmKelvin=2700,areaMeters=[3.8,18.6])
        lens_points=[side.point(x,h,.505) for x,h in
                     [(u-.061,z-.18),(u+.061,z-.18),(u+.061,z+.057),(u-.061,z+.057)]]
        hardware.face(lens_points)
        steady.face(lens_points,uv=[(.10,.97),(.90,.97),(.90,.98),(.10,.98)])
    roof_light=material("Night | soft amber roof glazing",(.39,.18,.062),.42,.74)
    uv_map=bpy.data.images.load(str(REVIEW_TEXTURES / "preview_Emissive.png"),check_existing=True)
    tree=roof_light.node_tree
    tex=tree.nodes.new("ShaderNodeTexImage")
    tex.image=uv_map
    mix=tree.nodes.new("ShaderNodeMixRGB")
    mix.blend_type="MULTIPLY"
    mix.inputs[0].default_value=1
    mix.inputs[2].default_value=(1,.55,.249,1)
    tree.links.new(tex.outputs["Color"],mix.inputs[1])
    tree.links.new(mix.outputs[0],tree.nodes.get("Principled BSDF").inputs["Emission Color"])
    for surface in exterior.skylight_faces:
        r0=[min(p[i] for p in surface) for i in (0,1)]
        dims=[max(max(p[i] for p in surface)-r0[i],1e-4) for i in (0,1)]
        # Thin, warm backing uses the window falloff map while staying behind the roof mullions.
        points=[(x,y,z+.009) for x,y,z in surface]
        uv=[(.06+.88*(x-r0[0])/dims[0],.059+.397*(y-r0[1])/dims[1]) for x,y,z in surface]
        roof_panels.face(points,uv=uv)
        steady.face(points,uv=uv)
    # Warm background across every tall arch. The stronger stage-specific
    # layer remains slightly forward and changes the brightest portions.
    outward={s.short:Vector(s.normal) for s in BRICK_SIDES}
    for pane in exterior.panes:
        if pane.section!="arch":
            continue
        points=[Vector(p)-outward[pane.side]*.007 for p in pane.world]
        uv=projection(points)
        roof_panels.face(points,uv=uv)
    lens=hardware.object(material("Lantern glow",(1,.60,.235),.46,2.42),rig)
    skylight=roof_panels.object(roof_light,rig)
    room_lights=[[] for i in range(10)]
    for room in exterior.rooms:
        group=group_for[("W","curtain",room.key)]
        u=(room.left+room.right)/2
        target=WEST.point(u,room.floor+.71,-3.32)
        rng=random.Random(seed(f"fixture/{room.key}"))
        warmth=rng.uniform(.0,.12)
        room_lights[group].append(add_light(rig,f"G{group} {room.kind} {room.key}","AREA",
                                           room.light_position,(1,.70+warmth,.42+warmth),
                                           rng.uniform(128,195),target,1.67))
    return sun,moon,exterior_lights,room_lights,lens,skylight,steady,native_fixture_plan


def softened_highlights(scene):
    tree=bpy.data.node_groups.new("Harold Washington Library | night glow", "CompositorNodeTree")
    scene.compositing_node_group=tree
    tree.interface.new_socket(name="Image",in_out="OUTPUT",socket_type="NodeSocketColor")
    render=tree.nodes.new("CompositorNodeRLayers")
    glow=tree.nodes.new("CompositorNodeGlare")
    glow.inputs["Type"].default_value="Fog Glow"
    glow.inputs["Threshold"].default_value=.54
    glow.inputs["Smoothness"].default_value=.60
    glow.inputs["Strength"].default_value=.24
    glow.inputs["Size"].default_value=.40
    output=tree.nodes.new("NodeGroupOutput")
    tree.links.new(render.outputs["Image"],glow.inputs["Image"])
    tree.links.new(glow.outputs["Image"],output.inputs["Image"])
    return glow


def render_views(scene, rig, light_overlays, draft, requested):
    sun, moon, ext, rooms, lens, skylight, _, _ = rig
    camera_data=bpy.data.cameras.new("Exterior review")
    camera=bpy.data.objects.new("Exterior review",camera_data)
    scene.collection.objects.link(camera)
    scene.camera=camera
    world=bpy.data.worlds.new("Review sky")
    world.use_nodes=True
    scene.world=world
    sky=world.node_tree.nodes.get("Background")
    scene.render.engine="CYCLES"
    scene.cycles.device="CPU"
    scene.cycles.samples=12 if draft else 21
    scene.cycles.use_denoising=True
    scene.cycles.max_bounces=7
    scene.cycles.transparent_max_bounces=5
    scene.render.image_settings.file_format="PNG"
    scene.render.resolution_percentage=62 if draft else 88
    scene.view_settings.view_transform="AgX"
    scene.view_settings.look="AgX - Medium High Contrast"
    highlights=softened_highlights(scene)
    frames = {
        "roof-plan": ((0,0,180),(0,0,35),119,940,1490,None),
        "roof-plan-night": ((0,0,180),(0,0,35),119,940,1490,0),
        "southeast-day": ((142,-188,111),(0,0,24),147,1440,1080,None),
        "state-street-day": ((80,0,3.0),(31.71,0,24),0,1250,1180,None),
        "northwest-day": ((-87,140,55),(0,10,25),122,1440,1020,None),
        "southwest-day": ((-137,-164,61),(0,0,26),139,1440,1020,None),
        "southeast-night": ((142,-188,111),(0,0,24),147,1440,1080,0),
        "state-street-night": ((81,5,4.5),(31.71,2,23),0,1250,1180,1),
        "idabwells-night": ((70,-143,18),(0,-32,23),89,1440,1010,2),
        "van-buren-night": ((73,145,30),(0,30,25),108,1440,1030,2),
        "entry-lights-state": ((168,0,28),(31.7,0,7.2),119,1480,333,1),
        "entry-lights-south": ((0,-159,24),(0,-54.6,7.0),69,1480,465,2),
        "entry-lights-north": ((0,159,24),(0,54.6,7.0),69,1480,465,2),
        "west-night-1": ((-105,-19,36),(-30,0,26.5),125,1500,800,0),
        "west-night-2": ((-105,-19,36),(-30,0,26.5),125,1500,800,1),
        "west-night-3": ((-105,-19,36),(-30,0,26.5),125,1500,800,2),
        "plymouth-court-day": ((-168,-10,35),(-31.7,0,24),121,1520,800,None),
        "plymouth-court-night": ((-168,-10,35),(-31.7,0,24),121,1520,800,0),
        "plymouth-court-corner-night": ((-125,-121,68),(0,-5,22),145,1440,990,1),
        "west-rooms-detail": ((-53,-8,19),(-27.7,0,16.6),32,1600,940,0),
    }
    names = (tuple(requested) if requested else
             ("southeast-day","southeast-night","west-night-1","west-rooms-detail") if draft else tuple(frames))
    for name in names:
        pos,target,scale,w,h,stage=frames[name]
        day=stage is None
        highlights.mute=day
        sun.hide_render=not day
        moon.hide_render=day
        sky.inputs["Color"].default_value=(.62,.72,.85,1) if day else (.20,.26,.42,1)
        sky.inputs["Strength"].default_value=.67 if day else .51
        lens.hide_render=day
        skylight.hide_render=day
        for obj in ext:
            obj.hide_render=day
        for gid,(_,objs) in enumerate(light_overlays):
            enabled=not day and gid in STAGES[stage]
            for obj in objs+rooms[gid]:
                obj.hide_render=not enabled
        camera.location=pos
        camera.rotation_euler=((0,0,0) if name.startswith("roof-plan") else
                               (Vector(target)-camera.location).to_track_quat("-Z","Y").to_euler())
        camera_data.type="ORTHO" if scale else "PERSP"
        camera_data.ortho_scale=scale or 100
        camera_data.lens=27.6
        scene.render.resolution_x=w
        scene.render.resolution_y=h
        scene.render.filepath=str(REVIEW / (name+("-draft" if draft else "")+".png"))
        bpy.ops.render.render(write_still=True)
        print(f"REVIEW_RENDER {name}",flush=True)
    # Open the editable file on a representative daytime view.
    highlights.mute=True
    sun.hide_render=False
    moon.hide_render=True
    sky.inputs["Color"].default_value=(.62,.72,.85,1)
    sky.inputs["Strength"].default_value=.67
    lens.hide_render=True
    skylight.hide_render=True
    for obj in ext+[o for set_ in rooms for o in set_]+[o for _,set_ in light_overlays for o in set_]:
        obj.hide_render=True
    camera.location=(142,-188,111)
    camera.rotation_euler=(Vector((0,0,24))-camera.location).to_track_quat("-Z","Y").to_euler()
    camera_data.type="ORTHO"
    camera_data.ortho_scale=147
    scene.render.resolution_x=1440
    scene.render.resolution_y=1080
    scene.render.resolution_percentage=100
    scene.render.filepath=str(REVIEW / "southeast-day.png")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--draft",action="store_true")
    parser.add_argument("--no-renders",action="store_true")
    parser.add_argument("--views",nargs="+")
    parser.add_argument("--exports-only",action="store_true")
    parser.add_argument("--review-only",action="store_true")
    args=parser.parse_args(sys.argv[sys.argv.index("--")+1:] if "--" in sys.argv else [])
    for target in (BASE,REVIEW,BUILD,REVIEW_TEXTURES,COVER_TEXTURES):
        target.mkdir(parents=True,exist_ok=True)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.preferences.filepaths.save_version=0
    scene=bpy.context.scene
    scene.unit_settings.system="METRIC"
    scene.unit_settings.scale_length=1
    scene["asset"]="GPT's Harold Washington Library"
    scene["author"]=AUTHOR
    scene["intended_release_version"]=RELEASE_VERSION
    scene["native_light_stage_seconds"]=list(STAGE_SECONDS)
    scene["native_night_cycle_seconds"]=sum(STAGE_SECONDS)
    scene["review_scope"]="Blender stage and material previews. Native runtime testing is a separate step."
    make_atlas(COVER_TEXTURES,STEM)
    mat=atlas_material(COVER_TEXTURES,STEM)
    released_mat=atlas_material(RELEASED_TEXTURES,"HWL","Released v1.1.0 exterior materials",.32)
    write_overlay_maps(REVIEW_TEXTURES,"preview")
    exterior=Exterior().build(RELEASED)
    production=collection("Library exterior and static interiors")
    objects=[part.object(mat,production) for part in exterior.parts if part.faces]
    for part in exterior.released_parts:
        original=part.object(released_mat,production)
        original["released_exterior"]=True
        objects.append(original)
    glass=exterior.clear_glass.object(review_glass(),collection("Plymouth Court clear glazing"))
    group_for,counts=pattern_for_window(exterior)
    overlays_,arch_meshes = overlays(exterior,group_for,collection("Three night patterns | grouped emissive geometry"))
    light_rig=make_rig(exterior,group_for)
    actual=sum(item["panes"] for item in counts.values())
    actual_lit=[sum(row["lit"][i] for row in counts.values()) for i in range(3)]
    print(f"GEOMETRY_READY {len(exterior.rooms)} rooms; {actual} panes; {actual_lit} lit",flush=True)
    if not args.no_renders and not args.exports_only:
        render_views(scene,light_rig,overlays_,args.draft,args.views)
    if args.review_only:
        return
    if not args.draft:
        merge_exterior_atlases()
    lods=None if args.draft else output_native_inputs(objects,overlays_,arch_meshes,light_rig[-2],glass,mat)
    blend=ROOT / "Source" / "GPTs_Harold_Washington_Library_Redesign.blend"
    if not args.draft and not args.exports_only:
        bpy.ops.wm.save_as_mainfile(filepath=str(blend))
    duration=sum(STAGE_SECONDS)
    intervals=[0,*(end/duration for end in accumulate(STAGE_SECONDS))]
    report={
        "title":"GPT's Harold Washington Library",
        "author":AUTHOR,
        "intendedReleaseVersion":RELEASE_VERSION,
        "status":"offline draft preview" if args.draft else "offline authoring candidate",
        "footprintMeters":[WIDTH,LENGTH],
        "corniceReferenceMeters":CORNICE,
        "nativeLot":[14,8],
        "exteriorSource":"Released v1.1.0 elevations with State Street entries mirrored on Plymouth Court",
        "roofSource":"User's north-up aerial photo, crossing vaults and four corner roof fields",
        "actualPaneCount":actual,"stagePaneCounts":actual_lit,
        "stagePanePercent":[round(n/actual*100,2) for n in actual_lit],
        "facades":counts,
        "plymouthCourt":{"curtainWallHeights":WEST_GLASS_HEIGHTS,
                         "curtainWallPanes":sum(p.side=="W" and p.section=="curtain" for p in exterior.panes),
                         "clerestoryPanes":sum(p.side=="W" and p.section=="gable" for p in exterior.panes),
                         "baseArchedWindows":sum(p.side=="W" and p.section=="base-arch" for p in exterior.panes)},
        "lighting":{"stageSeconds":list(STAGE_SECONDS),"durationSeconds":duration,
                    "keyTimesNormalized":intervals,"groupsOn":STAGES,
                    "randomizedNativeInstanceStart":True,"daylight":"native daylight gate to be applied on import",
                    "windowGroups":[dict(group=g,keys=intervals,
                                        values=[int(g in stage) for stage in (*STAGES,STAGES[0])])
                                     for g in range(10)],
                    "archWindowGroups":[dict(group=g,mesh=mesh.name,keys=intervals,
                                              values=[1.0 if g in stage else .58
                                                      for stage in (*STAGES,STAGES[0])])
                                        for g,mesh in arch_meshes],
                    "entryFixtures":light_rig[-1],
                    "steadyNightEffects":{"mesh":"HWLRedesignNightSteady",
                                          "animationIndex":-1,"daylightGate":"LightsOff",
                                          "entryLampCount":len(exterior.lanterns),
                                          "softArchPaneCount":sum(p.section=="arch" for p in exterior.panes),
                                          "roofSkylightFaces":len(exterior.skylight_faces)}},
        "westRooms":[dict(type=r.kind,group=group_for[("W","curtain",r.key)],
                          room=list(r.key),metersDeep=r.depth,lightLocation=r.light_position)
                     for r in exterior.rooms],
        "westRoomKinds":dict(Counter(room.kind for room in exterior.rooms)),
        "lods":lods,
    }
    file=BUILD / ("draft-audit.json" if args.draft else "exterior-redesign-audit.json")
    file.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    print(f"AUTHORING_COMPLETE {file}",flush=True)


if __name__=="__main__":
    main()
