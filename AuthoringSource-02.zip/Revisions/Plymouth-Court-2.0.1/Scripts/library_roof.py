"""Winter Garden roof traced from the supplied north-up aerial reference."""
from math import ceil, sqrt

from mathutils import Vector

from library_mesh import MeshPart


def divisions(a, b, n):
    return [a+(b-a)*i/n for i in range(n+1)]


class ReferenceRoof:
    # Field proportions are taken from the roof eaves in the reference.
    # Keep the previous model's roof height range and sculpture positions.
    EAVE = 45.64
    CORNER = 41.43
    RISE = 4.01
    GRID = 16
    RADIUS = 1.78

    def __init__(self, width, length):
        self.x_edge = width/2-.124
        self.y_edge = length/2-.124
        self.x_half = width*.190
        self.y_half = length*.105
        self.part = MeshPart("10 Winter Garden roof from aerial reference")
        self.skylights = []

    @classmethod
    def crown(cls, t):
        radius = cls.RADIUS
        base = sqrt(radius*radius-1)
        lifted = (sqrt(radius*radius-min(abs(t),1)**2)-base)/(radius-base)
        return cls.EAVE+cls.RISE*lifted

    def plane(self, pts, material, skylight=False):
        # An upward winding keeps the same visible normal on opposite arms.
        if (Vector(pts[1])-Vector(pts[0])).cross(Vector(pts[2])-Vector(pts[0])).z < 0:
            pts = pts[::-1]
        self.part.face(pts, material)
        if material=="skylight" or skylight:
            self.skylights.append(tuple(pts))

    def rib(self, a, b, radius, material, lift=.025):
        up = Vector((0,0,lift))
        self.part.pipe(Vector(a)+up,Vector(b)+up,radius,material,5)

    def crossing_point(self, x, y):
        return (x,y,max(self.crown(x/self.x_half),self.crown(y/self.y_half)))

    def central_glazing(self):
        xs = divisions(-self.x_half,self.x_half,self.GRID)
        ys = divisions(-self.y_half,self.y_half,self.GRID)
        p = self.crossing_point
        for i,(a,b) in enumerate(zip(xs,xs[1:])):
            for j,(c,d) in enumerate(zip(ys,ys[1:])):
                lo,br,hi,tl = p(a,c),p(b,c),p(b,d),p(a,d)
                if i==j:
                    inside = [(lo,br,hi),(lo,hi,tl)]
                elif i+j==self.GRID-1:
                    inside = [(lo,br,tl),(br,hi,tl)]
                else:
                    inside = [(lo,br,hi,tl)]
                for face in inside:
                    self.plane(face,"skylight")
        for x in xs:
            for a,b in zip(ys,ys[1:]):
                self.rib(p(x,a),p(x,b),.040,"green")
        for y in ys:
            for a,b in zip(xs,xs[1:]):
                self.rib(p(a,y),p(b,y),.040,"green")
        # The two groin seams make the distinct X visible in the overhead photo.
        for sign in (-1,1):
            ridge = [p(x,sign*x*self.y_half/self.x_half) for x in xs]
            for a,b in zip(ridge,ridge[1:]):
                self.rib(a,b,.098,"crest",.054)

    def arm(self, north_south, sign):
        half = self.x_half if north_south else self.y_half
        inner_along = self.y_half if north_south else self.x_half
        outer = self.y_edge if north_south else self.x_edge
        if north_south:
            glass_limit = 17.20 if sign>0 else 16.35
        else:
            glass_limit = 17.45 if sign>0 else 16.65

        def point(across, along):
            return ((across,along,self.crown(across/half)) if north_south else
                    (along,across,self.crown(across/half)))

        across = divisions(-half,half,self.GRID)
        glazed = divisions(sign*inner_along,sign*glass_limit,4)
        for a,b in zip(across,across[1:]):
            for u,v in zip(glazed,glazed[1:]):
                self.plane([point(a,u),point(b,u),point(b,v),point(a,v)],"skylight")
                self.rib(point(a,u),point(a,v),.040,"green")
                self.rib(point(a,u),point(b,u),.040,"green")
            end = sign*outer
            rim_a,rim_b = point(a,end),point(b,end)
            self.plane([point(a,glazed[-1]),point(b,glazed[-1]),rim_b,rim_a],"roof")
            self.rib(point(a,glazed[-1]),point(b,glazed[-1]),.079,"crest")
            self.rib(rim_a,rim_b,.104,"crest")
            self.rib(point(a,glazed[-1]),rim_a,.028,"roof",.015)
        for u,v in zip(glazed,glazed[1:]):
            self.rib(point(half,u),point(half,v),.040,"green")
        self.rib(point(half,glazed[-1]),point(half,sign*outer),.062,"green")
        self.rib(point(-half,glazed[-1]),point(-half,sign*outer),.062,"green")
        if north_south:
            self.roof_panels(point, sign)

    def roof_panels(self, point, sign):
        # Dark panel banks and paired openings are traced at their visible locations.
        if sign > 0:
            for left,right in ((-11.48,-4.49),(4.33,11.44)):
                self.panel_bank(point,left,right,17.35,36.10,5,11,"glass-blue",skylight=True)
            slots=((17.66,23.12),(23.71,29.37),(30.04,35.89))
        else:
            slots=((-22.01,-17.66),(-35.04,-30.78))
        for middle in (-2.11,2.05):
            for lo,hi in slots:
                self.panel_bank(point,middle-1.06,middle+1.06,lo,hi,2,4,"shadow",skylight=True)

    def panel_bank(self, point, left, right, lo, hi, columns, rows, color, skylight=False):
        def lifted(u,v):
            x,y,z = point(u,v)
            return (x,y,z+.038)
        xs=divisions(left,right,columns)
        ys=divisions(lo,hi,rows)
        for a,b in zip(xs,xs[1:]):
            for c,d in zip(ys,ys[1:]):
                self.plane([lifted(a,c),lifted(b,c),lifted(b,d),lifted(a,d)],color,skylight)
                self.rib(lifted(a,c),lifted(b,c),.025,"green",.016)
                self.rib(lifted(a,c),lifted(a,d),.024,"green",.016)
        for a,b in zip(xs,xs[1:]):
            self.rib(lifted(a,hi),lifted(b,hi),.045,"crest",.02)
        for c,d in zip(ys,ys[1:]):
            self.rib(lifted(right,c),lifted(right,d),.045,"crest",.02)

    def corner_fields(self, sx, sy):
        def p(u,v):
            return (sx*(self.x_half+u*(self.x_edge-self.x_half)),
                    sy*(self.y_half+v*(self.y_edge-self.y_half)),
                    self.EAVE+(self.CORNER-self.EAVE)*min(u,v))
        inside,north,east,corner=p(0,0),p(0,1),p(1,0),p(1,1)
        self.plane([inside,east,corner],"roof")
        self.plane([inside,corner,north],"roof")
        self.rib(inside,corner,.056,"green",.035)
        count=ceil((self.x_edge-self.x_half)/1.45)
        for u in divisions(0,1,count)[1:-1]:
            self.rib(p(u,0),p(u,u),.025,"roof",.019)
            self.rib(p(u,u),p(u,1),.025,"roof",.019)
        for a,b in [(north,corner),(corner,east),(north,inside),(inside,east)]:
            self.rib(a,b,.062,"green")
        x,y,_ = corner
        axes=((1,0,0),(0,1,0),(0,0,1))
        self.part.box((x,y,42.05),axes,(.47,.47,3.0),"crest")

    def perimeter(self):
        def outline(x,y,axis):
            if axis=="x" and abs(x)<=self.x_half:
                return self.crown(x/self.x_half)
            if axis=="y" and abs(y)<=self.y_half:
                return self.crown(y/self.y_half)
            ratio=((abs(x)-self.x_half)/(self.x_edge-self.x_half) if axis=="x" else
                   (abs(y)-self.y_half)/(self.y_edge-self.y_half))
            return self.EAVE+max(0,ratio)*(self.CORNER-self.EAVE)
        for sign in (-1,1):
            for axis in ("x","y"):
                edge,half=(self.x_edge,self.x_half) if axis=="x" else (self.y_edge,self.y_half)
                line=[-edge]+divisions(-half,half,self.GRID)+[edge]
                # Behind the retained gables, the skirt joins the new roof to the old shell.
                def at(u):
                    if axis=="x":
                        return (u,sign*self.y_edge,outline(u,sign*self.y_edge,axis))
                    return (sign*self.x_edge,u,outline(sign*self.x_edge,u,axis))
                lo=40.73 if axis=="y" and sign==-1 else 40.78
                for a,b in zip(line,line[1:]):
                    left,right=at(a),at(b)
                    skirt=[(left[0],left[1],lo),(right[0],right[1],lo),right,left]
                    if (axis=="x" and sign>0) or (axis=="y" and sign<0):
                        skirt.reverse()
                    self.part.face(skirt,"green")

    def build(self):
        self.central_glazing()
        for sign in (-1,1):
            self.arm(True,sign)
            self.arm(False,sign)
        for sx in (-1,1):
            for sy in (-1,1):
                self.corner_fields(sx,sy)
        self.perimeter()
        return self.part
